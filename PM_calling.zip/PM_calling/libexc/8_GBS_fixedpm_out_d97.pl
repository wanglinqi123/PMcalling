#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV <2);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 sample1.snp fixedfreq pair or single coverage";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my $sam1=$ARGV[0];
my $fixedfreq=$ARGV[1];
my $spend=$ARGV[2];
my $cov=$ARGV[3];
if (-e $sam1){
	print "$sam1 exists!\n";
}else{
	die "$sam1 does not exist!\n";
}

my (%posit,%chrom);

#chr     loc     ref     A       T       C       G
#gi|76786714|ref|NC_007432.1|    1       A       389     0       0       0
#gi|76786714|ref|NC_007432.1|    2       T       0       396     0       0
#gi|76786714|ref|NC_007432.1|    3       T       0       399     0       0


sub main (){
	
	print $sam1,"\n";	
	open(IN,"$sam1") or die "$!";
	open(OUT,">$sam1\_fixedpm0d$fixedfreq.txt") or die "$!";
	my $flag =0;
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		if($spend==0){
		my $total = $pp[3]+$pp[4]+$pp[5]+$pp[6];
		
		if($total <$cov){
			next;
		}
		
		my $countid=0;
		my $bases;
		my $zznum=$fixedfreq/100;
		if($pp[3]/$total>=$zznum){$countid=1;$bases="A";}
		if($pp[4]/$total>=$zznum){$countid=1;$bases="T";}
		if($pp[5]/$total>=$zznum){$countid=1;$bases="C";}
		if($pp[6]/$total>=$zznum){$countid=1;$bases="G";}
		
		if($countid == 0){
			next;
		}
		if($pp[2] ne $bases){
			print OUT $line,"\n";
		}
}else{
	my $total1 = $pp[3]+$pp[4]+$pp[5]+$pp[6];
	my $total2 = $pp[7]+$pp[8]+$pp[9]+$pp[10];
	my $total=$total1+$total2;
		if($total <5){
			next;
		}
	  my $countid=0;
		my $bases;
		my $zznum=$fixedfreq/100;
		if($pp[3]/$total1>=$zznum && $pp[7]/$total2>=$zznum){$countid=1;$bases="A";}
		if($pp[4]/$total1>=$zznum && $pp[8]/$total2>=$zznum){$countid=1;$bases="T";}
		if($pp[5]/$total1>=$zznum && $pp[9]/$total2>=$zznum){$countid=1;$bases="C";}
		if($pp[6]/$total1>=$zznum && $pp[10]/$total2>=$zznum){$countid=1;$bases="G";}
		
		if($countid == 0){
			next;
		}
		if($pp[2] ne $bases){
			print OUT $line,"\n";
		}	
	}
	 }
   close IN or die "$!";	 
   close OUT or die "$!";	
}
&main;
