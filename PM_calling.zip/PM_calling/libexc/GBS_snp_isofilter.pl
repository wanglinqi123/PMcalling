#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV<3);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 iso.out_file snplist_file pool_leastreadNO. iso_leastreadsNo. single or pair";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my $sam=$ARGV[0];
my $list =$ARGV[1];
my $ultraminor=$ARGV[2];
my $cutoff =$ARGV[3];
my $spend=$ARGV[4];
if (-e $sam){
	print "$sam exists!\n";
}else{
	die "$sam does not exist!\n";
}
my %hash_outposi;

sub main (){
	
	print $sam,"\n";	
	open(IN,"$sam") or die "$!";

	my $flag =0;
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		shift(@pp);
		my $ia = shift(@pp);
		shift(@pp);
		@{$hash_outposi{$ia}}=@pp;
	 }
   close IN or die "$!";
	if($spend==0){
	print $list,"\n";	
	open(IN1,"$list") or die "$!";
	open(OUT,">$list\_remained\_cutoff.txt") or die "$!";
	while(my $line=<IN1>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;		
		my @pp = split (/\t/,$line);
		my $a1=$pp[3];
		my $a2=$pp[4];
		my $a3=$pp[5];
		my $a4=$pp[6];
		#poolisoisopoolreadscutoff
		if(exists $hash_outposi{$pp[1]}){
			my @temp = @{$hash_outposi{$pp[1]}};
			if($temp[0]>=$cutoff){$a1=0;}#iso A reads
			if($temp[1]>=$cutoff){$a2=0;}#iso T reads
			if($temp[2]>=$cutoff){$a3=0;}#iso C reads
			if($temp[3]>=$cutoff){$a4=0;}#iso G reads
			if($a1<$ultraminor){$a1=0;}#pool A reads
			if($a2<$ultraminor){$a2=0;}#pool T reads
			if($a3<$ultraminor){$a3=0;}#pool C reads
			if($a4<$ultraminor){$a4=0;}#pool G reads
			my $total = $a1+$a2+$a3+$a4;
			if($total>0){
				print OUT $line,"\n";
			}

		}else{
		  if($a1<$ultraminor){$a1=0;}
			if($a2<$ultraminor){$a2=0;}
			if($a3<$ultraminor){$a3=0;}
			if($a4<$ultraminor){$a4=0;}
			my $total = $a1+$a2+$a3+$a4;
			if($total>0){
				print OUT $line,"\n";
		}
}
	}
	}else{
	print $list,"\n";	
	open(IN1,"$list") or die "$!";
	open(OUT,">$list\_remained\_cutoff$cutoff.txt") or die "$!";
	while(my $line=<IN1>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;		
		my @pp = split (/\t/,$line);
		my $a1=$pp[3];
		my $a2=$pp[4];
		my $a3=$pp[5];
		my $a4=$pp[6];
		my $a5=$pp[7];
		my $a6=$pp[8];
		my $a7=$pp[9];
		my $a8=$pp[10];
		#poolisoisopoolreadscutoff
		if(exists $hash_outposi{$pp[1]}){
			my @temp = @{$hash_outposi{$pp[1]}};
			if($temp[0]>=$cutoff){$a1=0;}#iso A reads
			if($temp[1]>=$cutoff){$a2=0;}#iso T reads
			if($temp[2]>=$cutoff){$a3=0;}#iso C reads
			if($temp[3]>=$cutoff){$a4=0;}#iso G reads
			if($temp[4]>=$cutoff){$a5=0;}#iso a reads
			if($temp[5]>=$cutoff){$a6=0;}#iso t reads
			if($temp[6]>=$cutoff){$a7=0;}#iso c reads
			if($temp[7]>=$cutoff){$a8=0;}#iso g reads
			if($a1<$ultraminor){$a1=0;}#pool A reads
			if($a2<$ultraminor){$a2=0;}#pool T reads
			if($a3<$ultraminor){$a3=0;}#pool C reads
			if($a4<$ultraminor){$a4=0;}#pool G reads
			if($a5<$ultraminor){$a5=0;}#pool a reads
			if($a6<$ultraminor){$a6=0;}#pool t reads
			if($a7<$ultraminor){$a7=0;}#pool c reads
			if($a8<$ultraminor){$a8=0;}#pool g reads
			my $total1 = $a1+$a2+$a3+$a4;
			my $total2 = $a5+$a6+$a7+$a8;
			if($total1>0 && $total2>0){
				print OUT $line,"\n";
			}

		}else{
		  if($a1<$ultraminor){$a1=0;}
			if($a2<$ultraminor){$a2=0;}
			if($a3<$ultraminor){$a3=0;}
			if($a4<$ultraminor){$a4=0;}
			if($a5<$ultraminor){$a5=0;}
			if($a6<$ultraminor){$a6=0;}
			if($a7<$ultraminor){$a7=0;}
			if($a8<$ultraminor){$a8=0;}
			my $total1 = $a1+$a2+$a3+$a4;
			my $total2 = $a8+$a5+$a6+$a7;
			if($total1>0 && $total2>0){
				print OUT $line,"\n";
		}
}
		}
	}
   close IN1 or die "$!";
   close OUT or die "$!";		
}
&main;
