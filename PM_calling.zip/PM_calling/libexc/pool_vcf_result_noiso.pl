#!usr/bin/perl
use strict;
my %hash;
my %hash1;
my %hash2;
my %hash3;
my $freq;
my $mfreq;
my $minorNumread;
$minorNumread=$ARGV[4]-1;
my %mutation;
my $name=$ARGV[6];
$mfreq=$ARGV[5];
my $fixed=$ARGV[7]/100;
my $aa;

##Usage: perl $_ cluster ttest flapping_indel rawPM minorNumread minorfreq $id fixfreq
open IN,"$ARGV[0]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash{$data[1]}=1;
	}
close IN;

open IN,"$ARGV[1]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash1{$data[1]}=1;
	}
close IN;

open IN,"$ARGV[2]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash2{$data[1]}=$_;
	}
close IN;
my %out;
open IN,"$ARGV[3]" or die;
my $file;
$file=0;
while(<IN>){

	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	pop @data;
	pop @data;
	pop @data;
	pop @data;
	my @data1=$data[4];
	push @data1,$data[3];
	push @data1,$data[5];
	push @data1,$data[6];
		@data1=sort{$a<=>$b} @data1;
	$out{$data[1]}=join("\t",@data);
	my $sum=$data[3]+$data[4]+$data[5]+$data[6];
	if($sum==0){next;
	}else{
	if($data[2] eq 'A'){
		if($data[4]>$minorNumread and ($data[4]/$sum)>=$mfreq){
			$mutation{$data[1]}="T";
			}
		if($data[5]>$minorNumread and ($data[5]/$sum)>=$mfreq){
		$mutation{$data[1]}="C";
		}
		if($data[6]>$minorNumread and ($data[6]/$sum)>=$mfreq){
			$mutation{$data[1]}="G";
			}	
		my @data2 = $data[4];
		push @data2,$data[5];
		push @data2,$data[6];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	}
		if($data[2] eq 'T'){
			if($data[3]>$minorNumread and ($data[3]/$sum)>=$mfreq){
			$mutation{$data[1]}="A";
			}
		if($data[5]>$minorNumread and ($data[5]/$sum)>=$mfreq){
		$mutation{$data[1]}="C";
		}
		if($data[6]>$minorNumread and ($data[6]/$sum)>=$mfreq){
			$mutation{$data[1]}="G";
			}	
			my @data2 = $data[3];
		push @data2,$data[5];
		push @data2,$data[6];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	}
		if($data[2] eq 'C'){
		if($data[3]>$minorNumread and ($data[3]/$sum)>=$mfreq){
			$mutation{$data[1]}="A";
			}
		if($data[4]>$minorNumread and ($data[4]/$sum)>=$mfreq){
		$mutation{$data[1]}="T";
		}
		if($data[6]>$minorNumread and ($data[6]/$sum)>=$mfreq){
			$mutation{$data[1]}="G";
			}	
			my @data2 = $data[3];
		push @data2,$data[4];
		push @data2,$data[6];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	}
		if($data[2] eq 'G'){
		if($data[3]>$minorNumread and ($data[3]/$sum)>=$mfreq){
			$mutation{$data[1]}="A";
			}
		if($data[5]>$minorNumread and ($data[5]/$sum)>=$mfreq){
		$mutation{$data[1]}="C";
		}
		if($data[4]>$minorNumread and ($data[4]/$sum)>=$mfreq){
			$mutation{$data[1]}="T";
			}	
			my @data2 = $data[3];
		push @data2,$data[5];
		push @data2,$data[4];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	} 
}
}
close IN;
open IN,$ARGV[0] or die;
while(<IN>){

	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	pop @data;
	pop @data;
	pop @data;
	pop @data;
	my @data1=$data[4];
	push @data1,$data[3];
	push @data1,$data[5];
	push @data1,$data[6];
		@data1=sort{$a<=>$b} @data1;
	$out{$data[1]}=join("\t",@data);
	my $sum=$data[3]+$data[4]+$data[5]+$data[6];
	if($sum==0){next;
	}else{
	if($data[2] eq 'A'){
		if($data[4]>$minorNumread and ($data[4]/$sum)>=$mfreq){
			$mutation{$data[1]}="T";
			}
		if($data[5]>$minorNumread and ($data[5]/$sum)>=$mfreq){
		$mutation{$data[1]}="C";
		}
		if($data[6]>$minorNumread and ($data[6]/$sum)>=$mfreq){
			$mutation{$data[1]}="G";
			}	
		my @data2 = $data[4];
		push @data2,$data[5];
		push @data2,$data[6];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	}
		if($data[2] eq 'T'){
			if($data[3]>$minorNumread and ($data[3]/$sum)>=$mfreq){
			$mutation{$data[1]}="A";
			}
		if($data[5]>$minorNumread and ($data[5]/$sum)>=$mfreq){
		$mutation{$data[1]}="C";
		}
		if($data[6]>$minorNumread and ($data[6]/$sum)>=$mfreq){
			$mutation{$data[1]}="G";
			}	
			my @data2 = $data[3];
		push @data2,$data[5];
		push @data2,$data[6];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	}
		if($data[2] eq 'C'){
		if($data[3]>$minorNumread and ($data[3]/$sum)>=$mfreq){
			$mutation{$data[1]}="A";
			}
		if($data[4]>$minorNumread and ($data[4]/$sum)>=$mfreq){
		$mutation{$data[1]}="T";
		}
		if($data[6]>$minorNumread and ($data[6]/$sum)>=$mfreq){
			$mutation{$data[1]}="G";
			}	
			my @data2 = $data[3];
		push @data2,$data[4];
		push @data2,$data[6];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	}
		if($data[2] eq 'G'){
		if($data[3]>$minorNumread and ($data[3]/$sum)>=$mfreq){
			$mutation{$data[1]}="A";
			}
		if($data[5]>$minorNumread and ($data[5]/$sum)>=$mfreq){
		$mutation{$data[1]}="C";
		}
		if($data[4]>$minorNumread and ($data[4]/$sum)>=$mfreq){
			$mutation{$data[1]}="T";
			}	
			my @data2 = $data[3];
		push @data2,$data[5];
		push @data2,$data[4];
		@data2 = sort{$a<=>$b} @data2;
		my $fixedfreq = $data2[2]/$sum;
		$freq=$data1[2]/$sum;
		if($data1[2]>$minorNumread and $freq>=$mfreq){
			if($fixedfreq >= $fixed ){
		 $aa="1/1:$sum"."\,"."$data1[2]"."\:"."$freq";
				}else{
		 $aa="0/1:$sum"."\,"."$data1[2]"."\:"."$freq";
	}
		$hash3{$data[1]}="$aa";
	}else{
		if($fixedfreq>=$fixed){
		 $aa="1/0:$sum"."\,"."$data1[2]"."\:"."$freq";
			}else{
		 $aa="0/0:$sum"."\,"."$data1[2]"."\:"."$freq";
		}
				$hash3{$data[1]}="$aa";
	}
	} 
}

	}
close IN;



open OUT,">$name\_final.vcf";
print OUT"##FORMAT GT:genetype,0/0 Not PM loci 0/1 PM loci 1/1 fixed mutation && PM loci 1/0 fixed mutation\n";
print OUT"##FORMAT AD Allelic depths for the ref and alt alleles in the loci\n";
print OUT"##FORMAT ALT  Count of reads supporting the alternate allele\n";
print OUT"##FORMAT MAF Minor Allele Frequency\n";
print OUT"CHROM\tlocation\tREF\tA\tT\tC\tG\tMUTATIONN\tFILTER\tFORMAT\tSAMPLE\tSAMPLE\_ISOGENIC\n";
foreach my $key(sort{$a<=>$b}keys %hash3){
if(exists $hash3{$key}){
	if(exists $hash{$key}){
		if(exists $hash1{$key}){
				if(exists $hash2{$key}){
					my @arr = split(/\t/,$hash2{$key});
					if($arr[-1] eq 'PASS'){
print OUT"$out{$key}\t"."$mutation{$key}\t"."PASS"."\t"."GT:AD,ALT:MAF"."\t$hash3{$key}\n";
}else{
	print OUT"$out{$key}\t"."$mutation{$key}\t"."Flapping Indel Filter"."\t"."GT:AD,ALT:MAF"."\t$hash3{$key}\n";
	}
}
		}else{
print OUT"$out{$key}\t"."$mutation{$key}\t"."Tail-test Filter"."\t"."GT:AD,ALT:MAF"."\t$hash3{$key}\n";
			}
		}else{
print OUT"$out{$key}\t"."$mutation{$key}\t"."Clustered PM Fliter"."\t"."GT:AD,ALT:MAF"."\t$hash3{$key}\n";		
			}
}
}