#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV<1);
sub USAGE{
	print "\n\nUSAGE:perl $0 GTF\n\n";
	die "$!\n";
	}
my $gtf=$ARGV[0];

if (-e $gtf){
	print "$gtf exists!\n";
}else{
	die "$gtf does not exist!\n";
}


my @file=glob("*diffindel_result.txt");
my %hash_gtfposi;



#snp list#
#3049	-C	NULL

sub main (){
   
#### import GTF   
  print $gtf,"\n";			
	open(IN2,"$gtf") or die "$!";
	while(my $line=<IN2>){
		chmod;
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		#print $pp[0],"\t",$pp[1],"\t",$pp[2],"\n";		
		if((!exists $pp[2])||($pp[2] ne "CDS")){
			#print $line,"\n";
			next;
		}

			$hash_gtfposi{$pp[8]}=$pp[3]."?".$pp[4]."?".$pp[6];
			#print $pp[3],"\t",$pp[4],"\t",$_,"\t",$pp[8],"\t",$pp[6],"\t",$pp[0],"\n";
	 }
   close IN2 or die "$!";
#### import SNP 
open(OUT1,">>indelanno\_sum.txt") or die "$!";
foreach my $id(@file){
	my $snp = $id;  
  print $snp,"\n";
  
  my $num_ucds=0;
  my $num_indel=0;
  my %geneid;

  open(IN3,"$snp") or die "$!";
  my $flagline=0;
  open(OUT,">$snp\_indelanno.txt") or die "$!";
  
	while(my $line=<IN3>){
		
		$flagline++;
		chmod;
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		
		my $pflag = 0;
		
		foreach my $key (keys %hash_gtfposi){
			my @temm= split (/\?/,$hash_gtfposi{$key});
			if (($pp[0]<$temm[0])||($pp[0]>$temm[1])){
				next;
			}
			$geneid{$key}=0;
		
		$pflag++;
}
		if ($pflag == 0){
			$num_ucds++;
			next;
		}
		print OUT "$line\n";
		$num_indel++;	

	 }
   close IN3 or die "$!";
   close OUT or die "$!";
   
   my $num_gene = keys %geneid;
   
   print OUT1  "$snp\ntotalline\t$flagline\nuCDS\t$num_ucds\ncds_indel\t$num_indel\ngene\t$num_gene\n";
   
  }  
close OUT1 or die "$!";		
}
&main;

