#!usr/bin/perl
use strict;
my %hash;
##Usage:perl frequency.pl depth_file indel_file
my %hash1;
my %indel;

open IN,"$ARGV[0]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash{$data[1]}=$data[2];
	}
close IN;
my $flag=0;

open IN,"$ARGV[1]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	if($flag==0){
		$flag++;
		next;
		}
	my @data=split(/\t/,$_);
	$indel{$data[0]}=$data[1];
	$hash1{$data[0]}=$data[2];
	}

open OUT,">$ARGV[1]\.freq\.out";
foreach my $key(sort{$a<=>$b}keys %hash1){
	if($indel{$key} eq 'I'){
	my $freq=$hash1{$key}/$hash{$key};
	print OUT"$key\t$hash1{$key}\t$hash{$key}\t$freq\n";
	}
if($indel{$key} eq 'D'){
	my $start1=$key-1;
	my $end1=$key+1;
	my $start=$hash{$start1};
	my $end_num=$hash{$end1};
	if($start >= $end_num){
		if($start>$hash1{$key}){
	my $freq=$hash1{$key}/$start;
	print OUT"$key\t$hash1{$key}\t$start\t$freq\n";
		}else{
	my $start1=$key-2;
	my $start=$hash{$start1};
	my $freq=$hash1{$key}/$start;
	print OUT"$key\t$hash1{$key}\t$start\t$freq\n";
			}
		}else{
			if($end_num>=$hash1{$key}){
		my $freq=$hash1{$key}/$end_num;
	print OUT"$key\t$hash1{$key}\t$end_num\t$freq\n";		
		}else{
	my $end1=$key+2;
	my $end_num=$hash{$end1};
	my $freq=$hash1{$key}/$end_num;
	print OUT"$key\t$hash1{$key}\t$end_num\t$freq\n";
			}
			}
	}
}
close OUT;