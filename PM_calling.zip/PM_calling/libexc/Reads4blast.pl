#!/usr/bin/perl -w
use warnings;
use strict;

die "USAGE: perl $0 <SRA file> \n" unless @ARGV == 1;

my $library = $ARGV[0];                    #LIBRARY FILE

&reads();

sub reads(){
	open (IN,"$library") or die "$!";
	open (OUT,">$library\_4blast.txt") or die "$!";
	my ($line1,$line2,$line3,$line4);

	while($line1 = <IN>){
		$line2 = <IN>;
    $line3 = <IN>;
    $line4 = <IN>;
    $line1 =~tr/\n\r//d;
    my @temp = split (/ /,$line1);
    my @tem = split (/@/,$temp[0]);
    #print $tem[1],"\n";
        
    print OUT ">",$tem[1],"\n";
    print OUT $line2;
		}
	close IN or die "$!";
	close OUT or die "$!";
	}