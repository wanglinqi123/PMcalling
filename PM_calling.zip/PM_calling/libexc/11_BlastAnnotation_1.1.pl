#!usr/bin/perl -w 
use strict;
use warnings;
#blast out�б��С�

&USAGE if (@ARGV!=1);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 blastresult_reform.txt";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my ($blast)=@ARGV;

if (-e $blast){
	print "$blast exists!\n";
}else{
	die "$blast does not exist!\n";
}

&main;

sub main (){
	
	print $blast,"\n";
	my $contigs_name;
	my $contigs_length;
	my $refgenome;
	my @ident;
	my $queryleft=0;
	my $queryright=0;
	my $printflag=0;
	my $printflag1=0;
		
	open(IN,"$blast") or die "$!";
	open(OUT,">$blast\_annotrans.txt") or die "$!";
	while(my $line=<IN>){
		chmod;
		chomp($line);
		if($line =~ /Query\=/){
			$line =~tr/\r\n//d;
			$contigs_name = $line;			
			my $len = <IN>;
			$len=~tr/\r\n//d;
			$contigs_length = $len;
			$printflag1=0;
	
		}
		if($line =~/\>/){						
			$line=~tr/\r\n//d;
			$refgenome = $line;
			$printflag1 =1;
		}

		if($line =~/Identities \=/){
			#print $line,"\n";							
			push @ident,$line;
			$printflag = 1;
		}


		if($line =~/QQuery/){
			#print $lin1,"\n";
			my @temp = split(/\t/,$line);
			if($queryleft == 0){
				$queryleft = $temp[1];
			}
			$queryright = $temp[2];							
		}
		
		if(($line =~/:/)&&($printflag == 1)){							
			push @ident,$queryleft;
			push @ident,$queryright;
			#print "$queryleft\n$queryright\n";
			$queryleft = 0;
			$queryright = 0;	
		}
		
		if(($line =~/\?/)&&($printflag1 == 1)){
			push @ident,$queryleft;
			push @ident,$queryright;
			#print "$queryleft\n$queryright\n";
			$queryleft = 0;
			$queryright = 0;
			
			print OUT	$contigs_name,"\t",$contigs_length,"\t",$refgenome,"\t",join("\t",@ident),"\n";
			@ident = ();
			$printflag =0;							
		}
		if($line =~/\*/){	
			print OUT	$contigs_name,"\t",$contigs_length,"\t",$refgenome,"\t",join("\t",@ident),"\n";
			@ident = ();
			$printflag =0;										
		}
	}
	
	close IN or die "$!";
	close OUT or die "$!";
}

					