#!usr/bin/perl -w 
use strict;
use warnings;
#blast out trans�б���

&USAGE if (@ARGV!=1);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 blastresult";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my ($blast)=@ARGV;

my %hash_query;

if (-e $blast){
	print "$blast exists!\n";
}else{
	die "$blast does not exist!\n";
}


#Query= NODE_24_length_52945_cov_63.462498	Length=53245	>gb|AE009948.1| Streptococcus agalactiae 2603V/R, complete genome	 Identities = 52900/53255 (99%), Gaps = 15/53255 (0%)	1	53245	 Identities = 936/939 (99%), Gaps = 0/939 (0%)	52307	53245	 Identities = 353/356 (99%), Gaps = 0/356 (0%)	1	356	 Identities = 34/34 (100%), Gaps = 0/34 (0%)	16875	16908	 Identities = 34/34 (100%), Gaps = 0/34 (0%)	363	396



&main;

sub main (){
	
	print $blast,"\n";
	
	open(IN,"$blast") or die "$!";
	open(OUT,">$blast\_distribution.txt") or die "$!";
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @temp = split (/\t/,$line);
		my ($name,$len,$da,$db,$dc);
		
		if($temp[0] =~ /Query\= (.+)/){
			$name = $1;
		}		
		#print $name,"\n";
		
		if(!exists $hash_query{$name}){
			if($temp[1] =~ /ength\=(.+)/){
				$len = $1;
			}			
			push @{$hash_query{$name}},$len;
		}
#######################

		my $mark1=0;
		my $mark2=0;
		my $classify;
	
		if($temp[2] =~/Streptococcus/){
			$mark1++;
		}
		if($temp[2] =~/Streptococcus agalactiae/){
			$mark2++;
		}
		if(($mark1+$mark2)==0){
			$classify = "Contamination";
		}
		if(($mark1==1)&&($mark2==1)){
			$classify = "GBS";
		}
		if(($mark1==1)&&($mark2==0)){
			$classify = "Streptococcus";
		}
###########################
	
		my $column =scalar(@temp);
		for(my $i = 0;$i<($column-3)/3;$i++){
		
		if($temp[$i*3+3] =~ /Identities \= (.+)\/(.+) \((.+)\%\),/){
			$da = $1;
			$db = $2;
			$dc = $3;
			
			print $dc,"?\n";
		}
		
		#print $classify."?".$dc."?".$temp[$i*5+7]."?".$temp[$i*5+8],"\n";

		push @{$hash_query{$name}},$classify."?".$dc."?".$temp[$i*3+4]."?".$temp[$i*3+5];

	}
	}	
	close IN or die "$!";

	print OUT "contigs_name\tLength\tGBS_len\tGBS%\tStrep_len\tStrep%\tContam_len\tContam%\tundefined\tundefined%\n";
	foreach my $key(keys %hash_query){
		my %hash_posit;
		my $flag=0;
		my @tem = @{$hash_query{$key}};
		#my $name = shift(@tem);
		my $lenth = shift (@tem);
		print $key,"\t",$lenth,"\n";
		for my $id(@tem){
			my @te = split(/\?/,$id);
			for($te[2]..$te[3]){
				$hash_posit{$_}{$te[0]."?".$flag}=$te[1];
				$flag++;
			}
			
		}

		
		my $classA=0;
		my $classB=0;
		my $classC=0;
		my $classD=0;
		my $classE=0;
		
		foreach my $key1(keys %hash_posit){
			my @firstclass = sort{$hash_posit{$key1}{$b}<=>$hash_posit{$key1}{$a}} keys %{$hash_posit{$key1}};
			my @firstclasshalf;
			my $firstname =0;
			for my $id(@firstclass){
				if($firstname == 0){
					push @firstclasshalf,$id;
					$firstname = $hash_posit{$key1}{$id};
				}else{
					if($hash_posit{$key1}{$id} == $firstname){
						push @firstclasshalf,$id;
					}
				}
			}
			my $class1 =0;
		  my $class2 =0;
		  my $class3 =0;
			
			for my $idd(@firstclasshalf){			
			my @tempA = split(/\?/,$idd);
			if($hash_posit{$key1}{$idd}<90){
				next;
			}
			if($tempA[0] eq "GBS"){
				$class1++;
			}
			if($tempA[0] eq "Streptococcus"){
				$class2++;
			}
			if($tempA[0] eq "Contamination"){
				$class3++;
			}
		}
		if(($class1==0)&&($class2==0)&&($class3==0)){
			$classD++; #no hits
		}
		if(($class1!=0)&&($class3==0)){
			$classA++; #GBS
		}
		if(($class1==0)&&($class2!=0)&&($class3==0)){
			$classB++; #Streptococcus
		}
		if(($class1==0)&&($class2==0)&&($class3!=0)){
			$classC++; #contam
		}	
		if((($class1!=0)||($class2!=0))&&($class3!=0)){
			$classE++; #unclassify
		}	
										
		}
		my $total = $classA + $classB + $classC +$classD +$classE;
		
		print OUT "$key\t$lenth\t$classA\t",$classA/$lenth,"\t$classB\t",$classB/$lenth,"\t$classC\t",$classC/$lenth,"\t$classD\t",$classD/$lenth,"\t$classE\t",$classE/$lenth,"\t","$total\n";
		
	}
	
	
	close OUT or die "$!";	
}

					