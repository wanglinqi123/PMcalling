#!usr/bin/perl
use strict;
my %hash;
my @data;
my $id;
if($#ARGV!=2){
	print "Usage:perl PM_deleteP.pl tem_file  infile ttest\n";
	}
	my $tmp=$ARGV[0];
	my $infile=$ARGV[1];
	my $ttest=$ARGV[2];
	my $outfile=$infile."\_ttest.txt";
open IN,"$tmp" or die;
my %temp;

while(<IN>){
	chomp;
	@data=split(/\t/,$_);
	if(exists $temp{$data[0]}){
	$temp{$data[0]}.="\t$data[3]";
	}else{
		$temp{$data[0]}=$data[3];
		}
	}
close IN;

foreach my $one(keys %temp){
	my @data=split(/\t/,$temp{$one});
	@data=sort{$a<=>$b}@data;
	if($#data>0){
		$hash{$one}=$data[$#data];
	}else{
		$hash{$one}=$temp{$one};
		}
	}
	

my %filter;
foreach my $key(keys %hash){
	if($hash{$key}>$ttest){
		$filter{$key}=$hash{$key};
		}
	}



my %PM;
open IN,"$infile" or die;
while(<IN>){
	chomp;
	@data=split(/\t/,$_);
	$PM{$data[1]}=$_;
	}
close IN;

open OUT,">>$outfile";
foreach my $key(sort{$a<=>$b}keys %filter){
	print OUT"$PM{$key}\n";
	}
close OUT;
