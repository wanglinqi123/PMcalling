#!usr/bin/perl
use strict;

#Uasge perl S0 sam PM PMread PMfrequency path;
if($#ARGV != 5)
{
	print "perl $0 <SAM> <POS> <MinRead> <MinFreqency> <baseq> outpath\n";
	exit;
}
my $out;
$out=$ARGV[5];
#my $tmp_dir = $out."/tmp_pool";

my $sam_file = $ARGV[0];
my $PM_file = $ARGV[1];
my $minor = $ARGV[2];
my $freq = $ARGV[3];
my $baseq = $ARGV[4];
open OUT,">$PM_file\.minor.txt";
open OUTA,">$PM_file\.major.txt";

open IN,"$PM_file" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	my $strand = &LoadCoverSAM($sam_file,$data[1],$baseq);
	my %hash;
	for my $t(@{$strand}){
			#print $data[1],"\t",join("\t",@{$t}),"\n";
			my $base_1 = ${$t}[2];
			my $plus_1 = ${$t}[1];
			#print "$data[1]\t$base_1\t$plus_1\n";
			if(exists $hash{$base_1}){
				$hash{$base_1}.="\t$plus_1";
			}else{
				$hash{$base_1}=$plus_1;
				}
		}
		my %out;
		my @out;
		if($data[3]>=$minor && $data[7] >=$freq){
			if(exists $out{$data[3]}){
				$out{$data[3]}.="\tA";
				}else{
			$out{$data[3]}="A";
		}
			push @out,$data[3];
			}
		if($data[4]>=$minor && $data[8] >=$freq){
			if(exists $out{$data[4]}){
				$out{$data[4]}.="\tT";
				}else{
			$out{$data[4]}="T";
		}
			push @out,$data[4];
			}
		if($data[5]>=$minor && $data[9] >=$freq){
			if(exists $out{$data[5]}){
				$out{$data[5]}.="\tC";
				}else{
			$out{$data[5]}="C";
		}
			push @out,$data[5];
			}
		if($data[6]>=$minor && $data[10] >=$freq){
			if(exists $out{$data[6]}){
				$out{$data[6]}.="\tG";
				}else{
			$out{$data[6]}="G";
		}
			push @out,$data[6];
			}
		@out = sort{$a<=>$b}@out;
		my %filter;
		for(my $i = 0;$i<$#out;$i++){
		my @filter = split(/\t/,$out{$out[$i]});
		foreach my $two(@filter){
			$filter{$two}=1;
			}
		}
	my %major;
	my @filter =split(/\t/,$out{$out[$#out]});
	foreach my $three(@filter){
		$major{$three}=1;
		}
	foreach my $key(keys %hash){
		if(exists $filter{$key}){
		my @plu = split(/\t/,$hash{$key});
		my $num_p=0;;
		my $num_l=0;;
		my $num_a=0;
		foreach my $two(@plu){
			$num_a++;
			if($two eq "+"){
				$num_p++;
			}
			if($two eq "-"){
				$num_l++;
				}
			}
		print OUT"$data[1]\t$key\t$num_a\t$num_p\t$num_l\n";
		}
	if(exists $major{$key}){
		my @plu = split(/\t/,$hash{$key});
		my $num_p=0;;
		my $num_l=0;;
		my $num_a=0;
		foreach my $two(@plu){
			$num_a++;
			if($two eq "+"){
				$num_p++;
			}
			if($two eq "-"){
				$num_l++;
				}
			}
		print OUTA"$data[1]\t$key\t$num_a\t$num_p\t$num_l\n";
		}
	}
	}
close IN;
close OUT;
close OUTA;

sub LoadCoverSAM()
{
	my $sam = shift;
	my $point = shift;
	my $basequality = shift;
	my @out = ();
	print "$point\n";
open SAM,"$sam" or die;
while(my $line=<SAM>){
		chomp $line;	
		my @arr = split/\t/,$line;
		#if($arr[5] =~ /[I,D]/g)
		#{
		#	print "$arr[5]**********\n";
		#}


###########求reads覆盖边界是否包含posit
			my @match = $arr[5] =~ /(\d+)[MDN]/g;
			my $match_sum = &sum(@match);
			my $start = $arr[3];
			my $end = $start+$match_sum - 1;
			if($point<$start || $point >$end)
			{
				#print "$line\n";
				next;
			}	

##############
			my $bs = '';
			my $bq = '';
			if(($arr[1] & 0x100) != 0)
			{
				print "$line\n";
				next;
			}	



###########计算reads长度 $mnum
		my @ms1 = $arr[5] =~/(\d+[MHSI])/g;
		my $mnum=0;
		foreach my $idc(@ms1){
			$idc =~tr/A-Z//d;
			$mnum += $idc;
		}	



			my %hash_subposit;
		  my %hash_realposit;


		######以genome site 为步长，计算对应reads site
		my @array = $arr[5] =~/(\d+[A-Z])/g;
		
		my $readsstartsite=0;
		my $genomestartsite=$arr[3]-1;
		my $leftsflag =0;
		my $mflag=0;
	  foreach my $ida(@array){
	  	my $ia = $ida;
	  	my $ib = $ida;
	  	$ia =~tr/A-Z//d;
	  	#print $ia,"\n";
			$ib =~tr/0-9//d;
			#print $ib,"\n";
			
			if(($mflag == 0 )&&($ib eq "H")){
				$leftsflag = $ia;
			}			

			
			if(($ib eq "H")||($ib eq "S")){
				$readsstartsite += $ia;
				next;
			}
			if($ib eq "M"){
				for(1..$ia){
					$readsstartsite++;
					$genomestartsite++;
					$hash_subposit{$genomestartsite}=$readsstartsite;				
				}
				$mflag++;
			}
			if(($ib eq "D")||($ib eq "N")){
				for(1..$ia){
					$genomestartsite++;					
				}
			}
			if($ib eq "I"){
				for(1..$ia){
					$readsstartsite++;					
				}
			}
		}
################如果posit含有对应的reads上的碱基（即不是indel）则从sam第10行截碱基.$hash_subpisit{$_}就是reads实际碱基位置，含H
			if (exists $hash_subposit{$point}){
				my $alleleposit = $hash_subposit{$point} - $leftsflag;
				#print "Position in genome = $key2 \n","Real offset of sequence in samfile = $alleleposit = $hash_subposit{$key2} - $leftsflag H \n";
				$bs = substr($arr[9],$alleleposit-1,1);
				$bq = substr($arr[10],$alleleposit-1,1);
				#print $pp[0],"\t",$firstc,"\t", "Real position of reads =",$hash_realposit{$key2},"\n";

				
				#print "$bs\t$bq\n$alleleposit\n$line\n";
				

			}else{
				next;
			}
			
			
			my $tail_len = $hash_subposit{$point};
     
			
			
			
			
			if(ord($bq)-33 < $basequality)
			{
				next;
			}
			my $plus = plusjudge($arr[1]);
			my @info = ($arr[0],$plus,$bs);
			push @out,\@info;	
	}
close SAM;
	return \@out;
	
}


sub plusjudge{
my $plus;
my $num = shift;
my $num1 = binary($num);
my @data=split(//,$num1);
if($data[-5]==1){
	$plus = "-"
}else{
	$plus ="+";
	}
}
sub binary{
   my $dec = shift;
	my $bin = unpack("B32", pack("N",$dec));
	return $bin;
}


sub sum()
{
	my $sum = 0;
	for my $a(@_)
	{
		$sum += $a;
	}
	return $sum;
}

sub ave()
{
	my $ave = 0;
	return &sum(@_)/($#_+1);
}