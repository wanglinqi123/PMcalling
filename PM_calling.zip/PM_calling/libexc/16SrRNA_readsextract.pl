#!usr/bin/perl -w 
use strict;
use warnings;
#16SrRNA �б���ȡ��

&USAGE if (@ARGV!=2);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 blastreads blastresult";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my ($blast,$list)=@ARGV;

if (-e $blast){
	print "$blast exists!\n";
}else{
	die "$blast does not exist!\n";
}

my %posit;

&main;

sub main (){
	
	print $list,"\n";
	
	open(IN,"$list") or die "$!";
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		my $nam = $pp[0];
	  $posit{$nam} = 1;		
	 }
   close IN or die "$!";
   
   print $blast, "\n";
   open(IN1,"$blast") or die "$!";
   open(OUT, ">$list\_extract.txt") or die "$!";
   while(my $line =<IN1>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my $line2 = <IN1>;
		chomp($line2);
		$line2=~tr/\r\n//d;		
		my @pp = split (/\t/,$line);
		my $nam1 = $pp[0];
		$nam1 =~tr/>//d;
		if (exists $posit{$nam1}){
			print OUT $line,"\n";
			print OUT $line2,"\n";

		}
	}
		#print $chrom{$temp[0]},"\n";
	 close IN1 or die "$!";
	 close OUT or die "$!";

}
	 	
	 	
	 	
			   				
		
