
use strict;
use warnings;

#MҪ�ﵽ50%���ϡ�
&USAGE if (@ARGV!=2);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 bwasam blastrawreads";
	print "\n\n\n\n";
	die "$!\n";
	}

my ($sam,$reads)=@ARGV;

my %posit;

#HWUSI-EAS1710_0016:2:85:13744:1887#0    89      1       3023588 255     115M    *       0       0       TGTCAAATTTTTTCTGATCATCTAATGTAATGATCATA
#TGTCTTTTTTCTTTGAGATTGTTTATGTAGTGGATTACATTGATGGATTTCCATATATAGAGCCATCTCTGCATCCC   BBBBBBBBBB^SZZWRX][]``]`]c\aa]]baa^``\^cE]ccccca[accddb`cdafee
#dedfdeded]fadfdffffdfdcffffaf]fddadd_[ee`dcdaeccf_fad   XA:i:2  MD:Z:8G31A74    NM:i:2  NH:i:1

sub baseCalculating (){
	
	print $sam,"\n";
	
	open(IN,"$sam") or die "$!";
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		
		if(!exists $posit{$pp[0]}){
			 	$posit{$pp[0]} = 1;
		}
	 }
   close IN or die "$!";
   
   print $reads,"\n";

	open(IN1,"$reads") or die "$!";
	open(OUT1,">$sam\_scalar.txt") or die "$!";
	while(my $line=<IN1>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		my $nam1 = $pp[0];
		$nam1 =~tr/>//d;
		my $line2 = <IN1>;		
		chomp($line2);
		$line2=~tr/\r\n//d;
						
		if(exists $posit{$nam1}){
			my @tem = split (/|/,$line2);
			my $col = scalar(@tem);
			 	$posit{$nam1} = $col;
		}
	 }
   close IN1 or die "$!";
   
   foreach my $key(keys %posit){
   	print OUT1 $key,"\t",$posit{$key},"\n";
  }
  close OUT1 or die "$!";
   
   print "Screening 50% M reads.....\n";
	
	open(IN2,"$sam") or die "$!";
	open(OUT,">$sam\_50rawreads.txt") or die "$!";
	while(my $line=<IN2>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		
		my @tempp = $pp[5] =~ /\d+[M]/g;
		my $mnum=0;
		foreach my $id(@tempp){
			$id =~tr/A-Z//d;
			$mnum += $id;
		}
		#print $mnum,"\n"; 
		if ($mnum/$posit{$pp[0]}>=0.5){
			print OUT $line,"\n";
		}
	 }
   close IN2 or die "$!"; 
   close OUT or die "$!";     			
		
}

&baseCalculating;