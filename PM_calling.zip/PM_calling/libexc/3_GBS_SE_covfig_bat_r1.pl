#!usr/bin/perl -w 
use strict;
use warnings;
use FindBin qw($Bin);
&USAGE if (@ARGV <4);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 gbs.sam genome  bs mapquality maplength";
	print "\n\n\n\n";
	die "$!\n";
	}
#��Ҫsamtools �� GBS_90M_filter.pl �ļ���
	
my $readfile = $ARGV[0];
my $genomepath = $ARGV[1];
my $mapquality=$ARGV[3];
my $bs=$ARGV[2];
my $maplength=$ARGV[4];
my @temp=split(/\//,$genomepath);
my $genome = $temp[scalar(@temp)-1];
my $path=$Bin;


sub main (){
	print $genome,"\n";
	system("samtools view -S -F $bs $readfile>$readfile\_F$bs.sam");
	system("samtools view -bt $genomepath.fai $readfile\_F$bs.sam >$readfile\_F$bs.bam");	
	system("samtools sort $readfile\_F$bs.bam -o $readfile\_F$bs.sort.bam");
	system("samtools index $readfile\_F$bs.sort.bam");
	system("awk '(\$5>=$mapquality){print \$0}' $readfile\_F$bs.sam > $readfile\_F$bs.sam\_q$mapquality.txt");
	system("samtools view -bt $genomepath.fai $readfile\_F$bs.sam\_q$mapquality.txt >$readfile\_F$bs.sam\_q$mapquality.txt.bam");
	system("samtools sort $readfile\_F$bs.sam\_q$mapquality.txt.bam -o $readfile\_F$bs.sam\_q$mapquality.txt.sort.bam");
	system("samtools index $readfile\_F$bs.sam\_q$mapquality.txt.sort.bam");
	system("perl $path/GBS\_90M\_filter.pl $readfile\_F$bs.sam\_q$mapquality.txt $maplength ");
	system("samtools view -bt $genomepath.fai $readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt >$readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.bam");
	system("samtools sort $readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.bam -o $readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.sort.bam");
	system("samtools index $readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.sort.bam");
	system("samtools  depth $readfile\_F$bs.sort.bam> $readfile\_F$bs.sort.bam.depth");
	system("samtools  depth $readfile\_F$bs.sam\_q$mapquality.txt.sort.bam> $readfile\_F$bs.sam\_q$mapquality.txt.sort.bam.depth");
	system("samtools  depth $readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.sort.bam> $readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.sort.bam.depth");
	system("awk '{(total+=\$3)};END{print total}' $readfile\_F$bs.sort.bam.depth>$readfile\_F$bs.sort.bam.depth.sum");
	system("awk '{(total+=\$3)};END{print total}' $readfile\_F$bs.sam\_q$mapquality.txt.sort.bam.depth>$readfile\_F$bs.sam\_q$mapquality.txt.sort.bam.depth.sum");
  system("awk '{(total+=\$3)};END{print total}' $readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.sort.bam.depth>$readfile\_F$bs.sam\_q$mapquality.txt\_$maplength\_Mresult.txt.sort.bam.depth.sum");	

	
}
&main;