#!usr/bin/perl
use strict;
use bigint;
my $pdf="./tmp_pool_ttest";
mkdir $pdf unless(-e $pdf);
#usage:perl ttest_file minor major PMread PMfreq coverage p-value

my %minor;
my $ttest_file = $ARGV[0];
my $minor_file = $ARGV[1];
my $major_file = $ARGV[2];
my $PMread = $ARGV[3];
my $freq = $ARGV[4];
my $coverage = $ARGV[5];
my $cutoff = $ARGV[6];
my %hash;

open IN,"$minor_file" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	if(exists $hash{$data[0]}){
		$hash{$data[0]}.=".."."$_";		
		}else{
	$hash{$data[0]}=$_;
	}
}
close IN;

open IN,"$major_file" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data = split(/\t/,$_);
	if(exists $hash{$data[0]}){
		my @test = split(/\.\./,$hash{$data[0]});
		foreach my $one(@test){
			my @minor = split(/\t/,$one);
			my $test1="$minor[0]"."$minor[1]";
			open OUT,">$pdf/$test1";
			for(my $i=1;$i<=$minor[3];$i++){
				print OUT"1\n";
				}
			for(my $i=1;$i<=$minor[4];$i++){
				print OUT"0\n";
				}
			close OUT;
			my $test2="$data[0]"."$data[1]";
			open OUT,">$pdf/$test2";
			for(my $i=1;$i<=$data[3];$i++){
				print OUT"1\n";
				}
			for(my $i=1;$i<=$data[4];$i++){
				print OUT"0\n";
				}
			close OUT;
			open OUT,">$pdf/$data[0]"."$minor[1]".".R";
			my $tt="$pdf/$data[0]"."$minor[1]";
			print OUT"data1<-read.table(\"$pdf/$test1\")\n";
			print OUT"data2<-read.table(\"$pdf/$test2\")\n";
			print OUT"result<-t.test(data1,data2,paired = FALSE)\n";
			print OUT"sink(\"$tt\.txt\")\n";
			print OUT"print(result)\n";
			print OUT "sink()\n";
			close OUT;
			system("R<$tt.R --vanilla > pool_R.log");	
			}
		}
	}
close IN;


open IN,"$ttest_file" or die;
open OUT,">$ttest_file\.filter_strand.txt";
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
		my %out;
		my @out;
		if($data[3]>=$PMread && $data[7] >=$freq){
			if(exists $out{$data[3]}){
				$out{$data[3]}.="\tA";
				}else{
			$out{$data[3]}="A";
		}
			push @out,$data[3];
			}
		if($data[4]>=$PMread && $data[8] >=$freq){
			if(exists $out{$data[4]}){
				$out{$data[4]}.="\tT";
				}else{
			$out{$data[4]}="T";
		}
			push @out,$data[4];
			}
		if($data[5]>=$PMread && $data[9] >=$freq){
			if(exists $out{$data[5]}){
				$out{$data[5]}.="\tC";
				}else{
			$out{$data[5]}="C";
		}
			push @out,$data[5];
			}
		if($data[6]>=$PMread && $data[10] >=$freq){
			if(exists $out{$data[6]}){
				$out{$data[6]}.="\tG";
				}else{
			$out{$data[6]}="G";
		}
			push @out,$data[6];
			}
		@out = sort{$a<=>$b}@out;
		my %filter;
		for(my $i = 0;$i<$#out;$i++){
		my @filter = split(/\t/,$out{$out[$i]});
		foreach my $two(@filter){
			$filter{$two}=1;
			}
		}
	foreach my $key(keys %filter){
		my $pvalue;
		my $file="$data[1]"."$key";
		open INA,"$pdf/$file.txt" or die;
		while(<INA>){
			$_=~tr/\r\n//d;
			if(($_=~/p-value \= (.*)/) or ($_=~/p-value \< (.*)/)){
				my $vv = $1;
				$pvalue=$vv;
				}
			}
		close INA;
	if($pvalue<$cutoff){
		if($key eq "A"){
			$data[3]=0;
			$data[7]=0;
			}
		if($key eq "T"){
			$data[4]=0;
			$data[8]=0;
			}
		if($key eq "C"){
			$data[5]=0;
			$data[9]=0;
			}
		if($key eq "G"){
			$data[6]=0;
			$data[10]=0;
			}
		}
		}
	my $total = $data[3]+$data[4]+$data[5]+$data[6];
		if($total ==0){
			next;
		}
		if($total<$coverage){
			next;
			}
		my $countid=0;
		if(($data[3]/$total>=$freq)&&($data[3]>=$PMread)){$countid++;}
		if(($data[4]/$total>=$freq)&&($data[4]>=$PMread)){$countid++;}
		if(($data[5]/$total>=$freq)&&($data[5]>=$PMread)){$countid++;}
		if(($data[6]/$total>=$freq)&&($data[6]>=$PMread)){$countid++;}
		
		if($countid>1){
		  print OUT $data[0],"\t",$data[1],"\t",$data[2],"\t",$data[3],"\t",$data[4],"\t","$data[5]\t$data[6]\t",$data[3]/$total,"\t",$data[4]/$total,"\t",$data[5]/$total,"\t",$data[6]/$total,"\n";
	  }
}
close OUT;

sub fac
{
    my $n = shift;
    if(1 == $n)
    {
        return 1;
    }
    else
    {
        return ($n * fac($n - 1));
    }
}
 