#!usr/bin/perl
use strict;
my %hash;
my @data;

open IN,"$ARGV[0]" or die;
open OUT,">$ARGV[1].indel";
while(<IN>){
	$_=~tr/\r\n//d;
	@data=split(/\t/,$_);
	my $sum=$data[2];
	if($sum<15){
		#print"$data[0]\n";
		next;
		}
	if($data[3]<0.005 or $data[3]>0.95){
		next;
		}
	
	print OUT"$_\n";
	}
close IN;
close OUT;