#!usr/bin/perl
use strict;
use Cwd;
use Getopt::Long;
use File::Basename;
my $help;my $infile;my $out;my $isofile;my $reference;my $plot;my $remove;my $file1;my $file2;
$out="test";
$plot="n";
$remove="n";
my $path=getcwd;
GetOptions(
'help|h!'=>\$help,
'in|i=s'=>\$file1,
'iso=s'=>\$file2,
'out|o=s'=>\$out,
'ref|r=s'=>\$reference,
'plot|p=s'=>\$plot,
'remove=s'=>\$remove,
);
if($help){
	print"***************************************************************\n";
	print"Usage:perl PM.pl -in infile -iso isofile -o out  [options]\n";
	print"***************************************************************\n";
	exit;
	}
$infile=basename($file1);
$isofile=basename($file2);
#ref length for plot	
my $seq;
my $len;
open IN,"$reference" or die;
while(<IN>){
$_=~tr/\r\n//d;
if(/>.*/){
next;
}else{
$seq.=$_;
next;
}
}
close IN;
$len=length($seq);
my $id;
my $file3;
$file3=basename($reference);
$file3=~/(.*)\..*/;
$id=$1;
my $id1;
($id1)=$infile=~/(.*)\..*?/;
mkdir $out unless(-e $out);
#iso mapping get 90Mresult
system("bwa index -a bwtsw $reference\n");
system("bwa mem -t 8 -a $reference $file2>$out/$isofile\_$id.sam\n");
my $isosam="$isofile"."\_"."$id.sam";
system("samtools view -S -F 4 $out/$isosam>$out/$isofile"."\_"."$id\_F4\.sam\n");
system("awk '(\$5>=35){print \$0}' $out/$isofile"."\_"."$id\_F4\.sam>$out/$isofile"."\_"."$id\_F4_q35\.txt\n");
system("perl GBS_90M_filter.pl $out/$isofile"."\_"."$id\_F4_q35\.txt \n");
system("perl GBS_SNP_calling.pl $out/$isofile"."\_"."$id\_F4_q35\.txt\_90Mresult\.txt $reference 0 0.03 15 3 \n");
if($remove eq 'y' or $remove eq 'yes' ){
system(unlink "$out/$isosam" );
system(unlink "$out/$isofile"."\_"."$id\_F4\.sam");
}
if($remove eq 'y' or $remove eq 'yes' ){
system(unlink "$out/$isofile"."\_"."$id\_F4_q35\.txt");
system(unlink "$out/$isofile"."\_"."$id\_F4_q35\.txt\_90Mresult\.txt");
system(unlink "$out/$isofile"."\_"."$id\_F4_q35\.txt\_90Mresult\.txt\.bam");
}
system("bwa mem -t 8 -a $reference $file1 > $out/$id1\_$id.sam\n");
system("perl 3_GBS_SE_covfig_bat_r1.pl $out/$id1\_$id.sam $reference\n");
system("perl GBS_SNP_calling.pl  $out/$id1\_$id.sam\_F4.sam\_q35.txt\_90Mresult.txt $reference 0 0.03 15 3\n");
system("perl GBS_snprecall_out.pl $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.snp 3 0.03\n");		
system("perl GBS_snprecall_out.pl $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out 3 0.01\n");
if($remove eq 'y' or $remove eq 'yes' ){
system(unlink "$out/$id1\_$id.sam");
system(unlink "$out/$id1\_$id.sam\_F4.sam");
system(unlink "$out/$id1\_$id.sam\_F4.sam\_q35.txt");
}
system("perl GBS_snprecall_out.pl $out/$isofile"."\_"."$id\_F4_q35\.txt\_90Mresult\.txt\.out 3 0.01\n");
system("perl GBS_snp_isofilter.pl $out/$isofile"."\_"."$id\_F4_q35\.txt\_90Mresult\.txt\.out\_read3\_freq0.01\.txt $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out\_read3\_freq0.01\.txt 4\n");
system("perl sam_site_reads_list2rd.pl $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out\_read3\_freq0.01\.txt\_remained\_cutoff4\.txt");
system("perl TailLenRatioTTest_V2.3.indel.pl $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\_alignment\.txt $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out\_read3\_freq0\.01\.txt\_remained\_cutoff4\.txt 1 $out");
system("perl PM_deleteP.pl $out/tmp_001/TMP_0 $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out\_read3\_freq0\.01\.txt\_remained\_cutoff4\.txt ");
system("perl 8_GBS_fixedpm_out_d97.pl $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out");
system("perl getPM.pl $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out\_read3\_freq0\.01\.txt\_remained\_cutoff4\.txt\_ttest\.txt $out/$id1\_$id.sam\_F4.sam_q35\.txt\_90Mresult\.txt\.out\_fixedpm0d97\.txt $out/PM.txt");
if($plot eq 'y'|$plot eq 'yes'){
system("perl GBS_depth_Rplot_refA909_r1.pl $len $out $id1\n");
chdir "$out";
system("gs -dBATCH -dEPSCrop -r100 -sDEVICE=png256 -sOutputFile=$id1\_$id\_w800h5.png $out/$id1\_w800h5.pdf\n");
chdir"$path";
}
if($remove eq 'y' or $remove eq 'yes' ){
system(unlink "$out/$id1\_$id.sam\_F4.sam\_q35.txt\_90Mresult\.txt");
system(unlink "$out/$id1\_$id.sam\_F4.sam\_q35.txt\_90Mresult\.txt\.pileup");
system(unlink "$out/$id1\_$id.sam\_F4.sam\_q35.txt\.bam");
system(unlink "$out/$isofile"."\_"."$id\_F4_q35\.txt\_90Mresult\.txt\.pileup");
}