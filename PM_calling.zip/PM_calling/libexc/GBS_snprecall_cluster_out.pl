#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV<5);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 .out_file leastreadsNo. leastfrequency pair or single coverage fixfreq";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my $sam=$ARGV[0];
my $ia =$ARGV[1];
my $ib =$ARGV[2];
my $spend=$ARGV[3];

my $coverage;
$coverage=$ARGV[4];
my $fixedfreq=$ARGV[5];
if (-e $sam){
	print "$sam exists!\n";
}else{
	die "$sam does not exist!\n";
}

sub main (){
	
	print $sam,"\n";
	
	open(IN,"$sam") or die "$!";
	open(OUT,">$sam\_clustered.txt") or die "$!";
	my $flag =0;
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		if($flag ==0){
			$flag++;
			next;
		}
		my @pp = split (/\t/,$line);
		if($spend==0){
		my $total = $pp[3]+$pp[4]+$pp[5]+$pp[6];
		if($total ==0){
			#print OUT $line,"\tZeroCoverage\n";
			next;
		}
		if($total<$coverage){
			next;
			}
	my $countid=0;
		if(($pp[3]/$total>=$ib)&&($pp[3]>=$ia)){$countid++;}
		if(($pp[4]/$total>=$ib)&&($pp[4]>=$ia)){$countid++;}
		if(($pp[5]/$total>=$ib)&&($pp[5]>=$ia)){$countid++;}
		if(($pp[6]/$total>=$ib)&&($pp[6]>=$ia)){$countid++;}
		
		if($countid>1){
		  print OUT $line,"\t",$pp[3]/$total,"\t",$pp[4]/$total,"\t",$pp[5]/$total,"\t",$pp[6]/$total,"\n";
	  }
		
}else{
	my $total=$pp[3]+$pp[4]+$pp[5]+$pp[6]+$pp[7]+$pp[8]+$pp[9]+$pp[10];
	if($total==0){
		next;
		}
		my $count1=0;
		my $count2=0;
		if((($pp[3]+$pp[7])/$total>=$ib)&&($pp[3]>=$ia && $pp[7]>=$ia)){$count1++;}
		if((($pp[4]+$pp[8])/$total>=$ib)&&($pp[4]>=$ia && $pp[8]>=$ia)){$count1++;}
		if((($pp[5]+$pp[9])/$total>=$ib)&&($pp[5]>=$ia && $pp[9]>=$ia)){$count1++;}
		if((($pp[6]+$pp[10])/$total>=$ib)&&($pp[6]>=$ia && $pp[10]>=$ia)){$count1++;}
		if($count1>1){
		  #print OUT $line,"\t",($pp[3]+$pp[7])/$total,"\t",($pp[8]+$pp[4])/$total,"\t",($pp[9]+$pp[5])/$total,"\t",($pp[10]+$pp[6])/$total,"\n";
	  }
	}
}
		

   close IN or die "$!";
   close OUT or die "$!";			
		
}
&main;

