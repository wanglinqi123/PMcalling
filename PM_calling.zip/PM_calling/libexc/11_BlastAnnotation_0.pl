#!usr/bin/perl -w 
use strict;
use warnings;
#blast out�б��С�

&USAGE if (@ARGV!=1);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 blastresult";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my ($blast)=@ARGV;

if (-e $blast){
	print "$blast exists!\n";
}else{
	die "$blast does not exist!\n";
}

&main;

sub main (){
	
	print $blast,"\n";
	my $flag = 0;
	
	open(IN,"$blast") or die "$!";
	open(OUT,">$blast\_reform.txt") or die "$!";
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		if($line =~ /Query\=/){
			print OUT "!\n$line\n";
		}
		if($line =~ /ength\=(.+)/){
			print OUT "$line\n";
		}
    my $firstc = substr($line,0,1);
		if($firstc =~/\>/){
			print OUT "?\n$line\n";
		}
		if($line =~ /Identities \=/){
		  	print OUT ":\n$line\n";
		}		
		if($line =~ /Query /){
			my @temp = split(" ",$line);			
			print OUT "QQuery\t$temp[1]\t$temp[3]\n";
			$flag=1;
		}
		if($line =~ /Effective search space used/){
			print OUT ":\n*\n";
			$flag=0;
		}		
		
				
		}
	
	close IN or die "$!";
	close OUT or die "$!";
}

					