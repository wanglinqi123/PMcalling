#!usr/bin/perl
use strict;


my %seq;
my $n;

# usage: perl 2_bwa_hit.pl <fq file>
open FQ , "$ARGV[0]" or die;
while(<FQ>){
	$_=~tr/\r\n//d;
	if($_){
		$n++;
		}
	}
close FQ;

my $seq_num=$n/4;

my @sam=glob("*.sam");
open OUT , ">>$ARGV[0].bwa.stat";
print OUT "genome\tfq file seq number\tbwa hit number\tproportion\(\%\)\n";


	my %hit;
	my $hit=0;
	my @data;
	
	open IN , "$ARGV[1]" or die;
	while(<IN>){
		$_=~tr/\r\n//d;
		my @data=split(/\t/,$_);
		if($data[3]==0){
			next;
			}
		if($_){			
			$hit{$data[0]}=1;
			}
		}
	close IN;
	
	foreach my $two (keys %hit){
		$hit++;
		}
	$hit=$hit-1;
	
	my $per=$hit/$seq_num*100;
	
	print OUT "$ARGV[1]\t$seq_num\t$hit\t$per\n";
close OUT;