#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV <2);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 sample1.indel.txt sample2.indel.txt";
	print "\n\n\n\n";
	die "$!\n";
	}
#�������fixed����Ϊ major allele Ƶ�� ���ڵ���97%��Ȼ�󣬽����������еĲ�ͬ��fixed ��ȡ�������бȽϡ�
#һ��������Ϊfixed����һ��������Ϊlowcov ���̬��λ�㣬�������϶�Ϊ��ͬ��	
my $sam1=$ARGV[0];
my $sam2=$ARGV[1];

my (%posit_sample1,%posit_sample2,%chrom);


sub main (){
	
	print $sam1,"\n";	
	open(IN,"$sam1") or die "$!";
	my $flag =0;
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		if($flag ==0){
			$flag++;
			next;
		}
		
		my @pp = split (/\t/,$line);
		$posit_sample1{$pp[1]}=$pp[3];		

	 }
   close IN or die "$!";	


	print $sam2,"\n";	
	open(IN1,"$sam2") or die "$!";


	
	my $flag1 =0;	
	while(my $line=<IN1>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		if($flag1 ==0){
			$flag1++;
			next;
		}

		$posit_sample2{$pp[1]}=$pp[3];	

	 }
	 close IN1 or die "$!";
	 
	 my $idd = keys %posit_sample2;
	 my $idd1 = keys %posit_sample1;
	 print "$idd\n$idd1\n";

	
	
	 open(OUT,">$sam1\_$sam2\_diffindel\_result.txt") or die "$!"; 
	 foreach my $key ( keys %posit_sample1){
	 	my $allele1 = $posit_sample1{$key};
	 	my $allele2;
	 	if (exists $posit_sample2{$key}){
	 		$allele2 = $posit_sample2{$key};
	 		if($allele1 ne $allele2){
	 			$chrom{$key} = $allele1."\t".$allele2;
	 		}
	 		delete $posit_sample1{$key};
	 		delete $posit_sample2{$key};
	 	}else{
	 		$chrom{$key} = $allele1."\tNULL";
	 	}
	}
	 	

	 	
	 	
	 	foreach my $key1 (keys %posit_sample2){
	 		my $allele3=$posit_sample2{$key1};
	 		$chrom{$key1} = "NULL\t".$allele3;
	 	}

	 	my $idd2 = keys %posit_sample2;
	 	print $idd2,"\n";	
	
	foreach my $key2 (sort{$a<=>$b} keys %chrom){
		print OUT $key2,"\t",$chrom{$key2},"\n";
	}
	
	close OUT or die "$!";
		
}
&main;
