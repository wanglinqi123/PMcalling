#!usr/bin/perl
use strict;
use warnings;

#MҪ�ﵽ90%���ϡ�
&USAGE if (@ARGV!=2);
sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 bwasam maplength";
	print "\n\n\n\n";
	die "$!\n";
	}

my $sam;
 $sam=$ARGV[0];
 print"$sam\n";
my $maplength=$ARGV[1];
#HWUSI-EAS1710_0016:2:85:13744:1887#0    89      1       3023588 255     115M    *       0       0       TGTCAAATTTTTTCTGATCATCTAATGTAATGATCATA
#TGTCTTTTTTCTTTGAGATTGTTTATGTAGTGGATTACATTGATGGATTTCCATATATAGAGCCATCTCTGCATCCC   BBBBBBBBBB^SZZWRX][]``]`]c\aa]]baa^``\^cE]ccccca[accddb`cdafee
#dedfdeded]fadfdffffdfdcffffaf]fddadd_[ee`dcdaeccf_fad   XA:i:2  MD:Z:8G31A74    NM:i:2  NH:i:1

sub baseCalculating (){
   
  print "Screening $maplength M result.....\n";
	
	open(IN2,"$sam") or die "$!";
	open OUT,">$sam\_$maplength\_Mresult.txt" or die "$!";
	while(my $line=<IN2>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		
		my @ms = $pp[5] =~ /(\d+[A-Z])/g;
		my $nnum=0;
		foreach my $idd(@ms){
			$idd =~tr/A-Z//d;
			$nnum += $idd;
		}
		
		my @tempp = $pp[5] =~ /\d+[M]/g;
		my $mnum=0;
		foreach my $id(@tempp){
			$id =~tr/A-Z//d;
			$mnum += $id;
		}
		#print $mnum,"\n"; 
		my $num=$maplength/100;
		if ($mnum/$nnum>=$num){
			print OUT $line,"\n";
		}
	 }
   close IN2 or die "$!"; 
   close OUT or die "$!";     			
		
}

&baseCalculating;
