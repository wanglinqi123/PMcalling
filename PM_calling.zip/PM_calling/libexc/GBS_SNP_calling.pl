#!/usr/bin/perl -w

use strict;
use warnings;
use FindBin qw($Bin);
if($#ARGV != 5)
{
	print "Usage:perl $0 <SAM> <Ref file> <whether pair end[0:no 1:yes]> <minor allele frequency> <overall coverage> <minor allele coverage> \n";
	exit;
}

my $sam = $ARGV[0];
my $ref_file = $ARGV[1];
my $pairend = $ARGV[2];
my $maf = $ARGV[3];
my $oc = $ARGV[4];
my $mac = $ARGV[5];

my $path=$Bin;
#system("samtools view -bt $ref_file.fai $sam >$sam.bam");
#system("samtools sort $sam.bam -o $sam.sort.bam");
system("samtools mpileup -B -f $ref_file $sam.sort.bam>$sam.pileup");
if($pairend == 0)####extend
{
	system("perl $path/pileup2base_no_strand.pl $sam.pileup 20 $sam.out");
	my $threshold = &GetThreshold("$sam.out");
	
}
else
{
	system("perl $path/pileup2base.pl $sam.pileup 20 $sam.out");
	my $threshold = &GetThreshold("$sam.out");
}






sub GetThreshold()
{
	my $file = shift;
	open SNP,"<$file";
	<SNP>;
	my @coverage = ();
	while(my $line = <SNP>)
	{
		chomp $line;
		my %hash_base = ();
		my @arr = split/\t/,$line;
		my $sum = &sum(@arr[3..$#arr]);
		push @coverage,$sum;
	}
	close SNP;
	@coverage = sort{$b<=>$a} @coverage;
	my $num = int($#coverage*0.01);
	return $coverage[$num];
}

sub sum()
{
	my $sum = 0;
	map{$sum += $_}@_;
	return $sum;
}
