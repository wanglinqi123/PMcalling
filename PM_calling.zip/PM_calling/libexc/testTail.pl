#!/usr/bin/perl
use warnings;
use strict;
use Statistics::TTest;
use threads;
use Cwd;
use Thread::Semaphore;
use AutoLoader;
use FindBin qw($Bin);

if($#ARGV != 6)
{
	print "perl $0 <SAM> <ref> read_number mfreq pairend coverage fixedfreq\n";
	exit;
}
my $path=$Bin;
my $sam = $ARGV[0];
my $ref_file = $ARGV[1];
my $readnum = $ARGV[2];
my $mfreq = $ARGV[3];
my $pairend = $ARGV[4];
my $coverage = $ARGV[5];
my $fixedfreq = $ARGV[6];
system("samtools view -bt $ref_file.fai $sam >$sam.bam");
system("samtools sort $sam.bam -o $sam.sort.bam");
system("samtools mpileup -B -f $ref_file $sam.sort.bam>$sam.pileup");
if($pairend == 0)####extend
{
	system("perl $path/pileup2base_no_strand.pl $sam.pileup 20 $sam.out");
}else{
		system("perl $path/pileup2base.pl $sam.pileup 20 $sam.out");
	}
system("perl $path/GBS_snprecall_cluster_out.pl $sam.out $readnum $mfreq $pairend $coverage $fixedfreq ")