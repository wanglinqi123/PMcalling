#!usr/bin/perl
use strict;
my %hash1;
my @data;
my %filter;
my %hash;
if($#ARGV!=2){
	print"Usage: perl getPM.pl ttestfilteredPMfile fixedPMfile outfile";
	}
	my $cutoff=$ARGV[0];
	my $fixed=$ARGV[1];
	my $out=$ARGV[2];
open IN,"$cutoff" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	@data=split(/\t/,$_);
	$hash1{$data[1]}=$_;
	}
close IN;

open IN,"$fixed" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	@data=split(/\t/,$_);
	$hash{$data[1]}=$_;
	}
close IN;
foreach my $key(keys %hash1){
	if(exists $hash{$key}){
		print"$key\n";
		next;
		}else{
			$filter{$key}=$hash1{$key};
			}
		}
	open OUT,">$out";
	foreach my $key(sort {$a<=>$b}keys %filter){
		print OUT"$filter{$key}\n";
		}
	close OUT;