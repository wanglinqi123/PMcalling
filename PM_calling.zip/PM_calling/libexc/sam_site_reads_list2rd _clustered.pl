#!usr/bin/perl -w 
use strict;
use warnings;

#extract alignments that cover a given site

&USAGE if (@ARGV<2);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 sam list";
	print "\n\n\n\n";
	die "$!\n";
	}
my $sam = $ARGV[0];
my $list = $ARGV[1];

if (-e $list){
	print "$list exists!\n";
}else{
	die "$list does not exist!\n";
}



my %chrom;
my %hash_posit;

#HWUSI-EAS1710_0016:3:15:6140:21245#0/1	0	MT	457	255	90M	*	0	0	CATTTATAATACACGACAGCTAAGACCCAAACTGGGATTAGATACCCCACTATGCTTAGCCATAAACCTAAATAATTAAATTTAACAAAA	*	AS:i:900	H0:i:1	H1:i:0	H2:i:0	NM:i:0	NH:i:1	IH:i:1	

sub main (){
	open(IN1,"$list") or die "$!";
	while(my $line=<IN1>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		push @{$hash_posit{$pp[1]}},0;
	}
	close IN1 or die "$!";	
	
	print $sam,"\n";	
	open(IN,"$sam") or die "$!";
	my $lineflag=0;
	while(my $line=<IN>){
		$lineflag++;
		if($lineflag%10000 == 0){
		#	print $lineflag,"\n";
		}

		my %hash_subposit;
		my %hash_realposit;

		chmod;
		chomp($line);

		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		if($#pp<10){
			#print "$line\n";
			next;
			}
		######���㸲�ǻ�������ұ߽磬���������list�е�λ�ã���next
		my @ms = $pp[5] =~/(\d+[MDN])/g;
		my $nnum=0;
		foreach my $idd(@ms){
			$idd =~tr/A-Z//d;
			$nnum += $idd;
		}	
		my $endsite = $pp[3] + $nnum -1;
		
		my $countflag=0;
		
		for my $key1 (keys %hash_posit){
			if (($key1<= $endsite)&&($key1>= $pp[3])){
				$countflag++;
			}
		}
		if($countflag ==0){
			next;
		}
				

		####���ж���������������򣬾Ͳ��ü���reads ���ȡ�
		
		my $FRflag;
		if($pp[1] == 0){
			$FRflag = "+";
		}else{					
			my $Str = sprintf("%b","$pp[1]");		
			my @temp=split(/|/,$Str);
			if($temp[scalar(@temp)-5] == 0){
				$FRflag = "+";
			}else{
				$FRflag = "-";
				#print $pp[0],"\t",$pp[1],"\n";
			}		
		}
		#print $FRflag,"\t";
		
		
		######����reads����
		my @ms1 = $pp[5] =~/(\d+[MHSI])/g;
		my $mnum=0;
		foreach my $idc(@ms1){
			$idc =~tr/A-Z//d;
			$mnum += $idc;
		}	
		#print $pp[0],"\t",$pp[1],"\t",$pp[2],"\t",$pp[3],"\t",$endsite,"\t",$mnum,"\n";		
		
		######��genome site Ϊ�����������Ӧreads site
		my @array = $pp[5] =~/(\d+[A-Z])/g;
		
		my $readsstartsite=0;
		my $genomestartsite=$pp[3]-1;
		my $leftsflag =0;
		my $mflag=0;
	  foreach my $ida(@array){
	  	my $ia = $ida;
	  	my $ib = $ida;
	  	$ia =~tr/A-Z//d;
	  	#print $ia,"\n";
			$ib =~tr/0-9//d;
			#print $ib,"\n";
			
			if(($mflag == 0 )&&($ib eq "H")){
				$leftsflag = $ia;
			}			

			
			if(($ib eq "H")||($ib eq "S")){
				$readsstartsite += $ia;
				next;
			}
			if($ib eq "M"){
				for(1..$ia){
					$readsstartsite++;
					$genomestartsite++;
					$hash_subposit{$genomestartsite}=$readsstartsite;
					if($FRflag eq "+"){
					$hash_realposit{$genomestartsite}=$readsstartsite;
				}else{
					$hash_realposit{$genomestartsite}=$mnum-$readsstartsite+1;
					
				}					
				}
				$mflag++;
			}
			if(($ib eq "D")||($ib eq "N")){
				for(1..$ia){
					$genomestartsite++;					
				}
			}
			if($ib eq "I"){
				for(1..$ia){
					$readsstartsite++;					
				}
			}
		}
		


		for my $key2 (keys %hash_posit){
			if (exists $hash_subposit{$key2}){
				
				$chrom{$line}=0;
				

			}
			
		}

	 }
   close IN or die "$!";
 
   
		open (OUT1,">$sam\_clustered\_alignment.txt") or die $!;

		for my $key2 (sort{$a cmp $b} keys %chrom){
				
				print OUT1 "$key2\n";
				
			
		}
	  close OUT1 or die $!;   			
		
}
&main;
