#!usr/bin/perl
use strict;
my %hash;
my $inser;
my $del;
my $start;
my %hash1;
my %hash_num;
##usage:perl $_ sam
open IN,"$ARGV[0]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$start=$data[3];
	$inser=$data[3];
	$del=$data[3];
	if($data[5]=~/I/ or $data[5]=~/D/){
		my @total= $data[5]=~/(\d+[A-Z])/g;;
		foreach my $ida(@total){
			my $ia = $ida;
	  	my $ib = $ida;
	  	$ib =~tr/A-Z//d;
	  	$ia =~tr/0-9//d;
	  	#$ia=M
	  	if($ia eq 'H' or $ia eq 'S'){
	  		next;
	  		}
	  	if($ia eq 'M'){
	  		$start+=$ib;
	  		}
	  		if($ia eq 'I'){
	  			$inser=$start;
	  			my $key="$data[0]"."\t"."$inser";
	  			$hash{$key}=$ib;
	  			$hash_num{$inser}.="$ib\t";
	  			#$start+=$ib;
	  			}
	  		if($ia eq 'D'){
	  			$del=$start;	  			
	  			my $key="$data[0]"."\t"."$del";
	  			$hash1{$key}=$ib;
	  		$hash_num{$del}.="$ib\t";
	  			$start+=$ib;
	  			}
			}
		}
	}
close IN;

my %hash_inser;
my %indel;
my %hash_read;
my @indel;
my %type;
foreach my $key(keys %hash){
	$indel{$key}=$hash{$key};
	my @data;
	@data=split(/\t/,$key);
	$hash_inser{$data[1]}++;
	$type{$data[1]}='I';
	$hash_read{$data[1]}.="$data[0]\t";
	}
	
foreach my $key(keys %hash1){
	$indel{$key}=$hash1{$key};
	my @data;
	@data=split(/\t/,$key);
	$hash_inser{$data[1]}++;
		$type{$data[1]}='D';
	$hash_read{$data[1]}.="$data[0]\t";
	}

my %hash_region;
foreach my $key(keys %hash_num){
	my @data=split(/\t/,$hash_num{$key});
	@data=sort{$a<=>$b} @data;
	$hash_region{$key}=$data[-1];
	}
foreach my $key(keys %hash_inser){
	if($hash_inser{$key}>=2){
	push @indel,$key;
	}
}

@indel=sort{$a<=>$b} @indel;
my $i;
my %filter;
my %tags;
my $xx;

foreach my $one(@indel){
	$xx=$one;
	  # print "$one\n";
	if($tags{$one}==1){
		#print "$one\n";
	next;
		}else{
   my %plus;
	my @read_1=split(/\t/,$hash_read{$one});
	foreach my $two(@read_1){
		$plus{$two}=1;
		}
  for($i=1;$i<=6;$i++){
  	$xx=$one+$i;
  	if(exists $hash_inser{$xx}){
  		#print "$xx\n";
  		$tags{$xx}=1;
  		my $zz=0;
		  my @read_2=split(/\t/,$hash_read{$xx});
		foreach my $three(@read_2){
			if(exists $plus{$three}){
				$zz++;
			}
			}
			my $data1=$hash_inser{$one};
			my $data2=$hash_inser{$xx};
			my $sum=$data1+$data2-$zz;
			#$hash_inser{$one}=$sum;
			#print "$one\t$data1\t$data2\t$zz\n";
			$hash_inser{$one}=$sum;
			$filter{$one}="$one\t$type{$one}\t$sum\t$hash_region{$one}";
			$filter{$xx}=0;	
  	}else{
    $filter{$one}="$one\t$type{$one}\t$hash_inser{$one}\t$hash_region{$one}";
  		}
  	}
	}
}		

		
		open OUT,">$ARGV[0].indel";
			print OUT"loci\tindel\tcoverage\tlength\n";
		foreach my $key(@indel){
			if($filter{$key}>0){
				my @data=split(/\t/,$filter{$key});
				if($data[2]>=4){
			print OUT"$filter{$key}\n";
			}
		}
		}
		close OUT;
		
