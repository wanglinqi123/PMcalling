#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV <2);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 sample1.out sample2.out";
	print "\n\n\n\n";
	die "$!\n";
	}
#�������fixed����Ϊ major allele Ƶ�� ���ڵ���97%��Ȼ�󣬽����������еĲ�ͬ��fixed ��ȡ�������бȽϡ�
#һ��������Ϊfixed����һ��������Ϊlowcov ���̬��λ�㣬�������϶�Ϊ��ͬ��	
my $sam1=$ARGV[0];
my $sam2=$ARGV[1];

my (%posit_sample1,%posit_sample2,%chrom);

#chr     loc     ref     A       T       C       G
#gi|76786714|ref|NC_007432.1|    1       A       389     0       0       0
#gi|76786714|ref|NC_007432.1|    2       T       0       396     0       0
#gi|76786714|ref|NC_007432.1|    3       T       0       399     0       0


sub main (){
	
	print $sam1,"\n";	
	open(IN,"$sam1") or die "$!";
	my $flag =0;
	while(my $line=<IN>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		if($flag ==0){
			$flag++;
			next;
		}
		
		my @pp = split (/\t/,$line);
		my $total = $pp[3]+$pp[4]+$pp[5]+$pp[6];
		
		if($total <5){
			next;
		}
		
		my $countid=0;
		my $bases;
		if($pp[3]/$total>=0.97){$countid=1;$bases="A";}
		if($pp[4]/$total>=0.97){$countid=1;$bases="T";}
		if($pp[5]/$total>=0.97){$countid=1;$bases="C";}
		if($pp[6]/$total>=0.97){$countid=1;$bases="G";}
		
		if($countid == 0){
			next;
		}
		$posit_sample1{$pp[1]}=$bases;		

	 }
   close IN or die "$!";	


	print $sam2,"\n";	
	open(IN1,"$sam2") or die "$!";


	
	my $flag1 =0;	
	while(my $line=<IN1>){
		chmod;
		chomp($line);
		$line=~tr/\r\n//d;
		my @pp = split (/\t/,$line);
		if($flag1 ==0){
			$flag1++;
			next;
		}
		my $total = $pp[3]+$pp[4]+$pp[5]+$pp[6];
		
		if($total <5){
			next;
		}
		
		my $countid=0;
		my $bases;
		if($pp[3]/$total>=0.97){$countid=1;$bases="A";}
		if($pp[4]/$total>=0.97){$countid=1;$bases="T";}
		if($pp[5]/$total>=0.97){$countid=1;$bases="C";}
		if($pp[6]/$total>=0.97){$countid=1;$bases="G";}
		
		if($countid == 0){
			next;
		}
		$posit_sample2{$pp[1]}=$bases;	

	 }
	 close IN1 or die "$!";
	 
	 open(OUT,">$sam1\_$sam2\_diff\_result.txt") or die "$!"; 
	 foreach my $key (sort{$a<=>$b} keys %posit_sample1){
	 	my $allele1 = $posit_sample1{$key};
	 	my $allele2;
	 	if (exists $posit_sample2{$key}){
	 		$allele2 = $posit_sample2{$key};
	 		if($allele1 ne $allele2){
	 			print OUT "$key\t$allele1\t$allele2\n";
	 		}
	 	}
	}
	close OUT or die "$!";
		
}
&main;
