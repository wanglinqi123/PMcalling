#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV <2);

sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 single_end_file genome";
	print "\n\n\n\n";
	die "$!\n";
	}
	
my $readfile = $ARGV[0];
my $genomepath = $ARGV[1];

my @temp=split(/\//,$genomepath);
my $genome = $temp[scalar(@temp)-1];



sub main (){
	print $genome,"\n";
	system("bwa mem -t 8 -a $genomepath $readfile>$readfile\_$genome\_bwa010.sam");
	system("samtools view -S -F 4 $readfile\_$genome\_bwa010.sam>$readfile\_$genome\_bwa010\_F4.sam");
	system("samtools view -bt $genomepath.fai $readfile\_$genome\_bwa010\_F4.sam >$readfile\_$genome\_bwa010\_F4.bam");	
	system("samtools sort $readfile\_$genome\_bwa010\_F4.bam $readfile\_$genome\_bwa010\_F4.sort");
	system("samtools index $readfile\_$genome\_bwa010\_F4.sort.bam");
	system("awk '(\$5>=35){print \$0}' $readfile\_$genome\_bwa010\_F4.sam > $readfile\_$genome\_bwa010\_F4.sam\_q35.txt");
	system("samtools view -bt $genomepath.fai $readfile\_$genome\_bwa010\_F4.sam\_q35.txt >$readfile\_$genome\_bwa010\_F4.sam\_q35.txt.bam");
	system("samtools sort $readfile\_$genome\_bwa010\_F4.sam\_q35.txt.bam $readfile\_$genome\_bwa010\_F4.sam\_q35.txt.sort");
	system("samtools index $readfile\_$genome\_bwa010\_F4.sam\_q35.txt.sort.bam");
	system("perl GBS\_90M\_filter.pl $readfile\_$genome\_bwa010\_F4.sam\_q35.txt");
	system("samtools view -bt $genomepath.fai $readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt >$readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.bam");
	system("samtools sort $readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.bam $readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.sort");
	system("samtools index $readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.sort.bam");
	system("samtools  depth $readfile\_$genome\_bwa010\_F4.sort.bam> $readfile\_$genome\_bwa010\_F4.sort.bam.depth");
	system("samtools  depth $readfile\_$genome\_bwa010\_F4.sam\_q35.txt.sort.bam> $readfile\_$genome\_bwa010\_F4.sam\_q35.txt.sort.bam.depth");
	system("samtools  depth $readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.sort.bam> $readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.sort.bam.depth");
	system("awk '{(total+=\$3)};END{print total}' $readfile\_$genome\_bwa010\_F4.sort.bam.depth>$readfile\_$genome\_bwa010\_F4.sort.bam.depth.sum");
	system("awk '{(total+=\$3)};END{print total}' $readfile\_$genome\_bwa010\_F4.sam\_q35.txt.sort.bam.depth>$readfile\_$genome\_bwa010\_F4.sam\_q35.txt.sort.bam.depth.sum");
	system("awk '{(total+=\$3)};END{print total}' $readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.sort.bam.depth>$readfile\_$genome\_bwa010\_F4.sam\_q35.txt\_90Mresult.txt.sort.bam.depth.sum");	

	
}
&main;