#!/usr/bin/perl
use warnings;
use strict;
use Statistics::TTest;
use threads;
use Cwd;
use Thread::Semaphore;
use AutoLoader;

if($#ARGV != 4)
{
	print "perl $0 <SAM> <POS> <core> <minor read>\n outpath";
	exit;
}

my $sam_file = $ARGV[0];
my $posTable = $ARGV[1];
my $core = $ARGV[2];
my $PMread = $ARGV[3];
my $out;
$out=$ARGV[4];



my @arr_pos = ();
my %hash_set = ();
my $name = $posTable;
$name =~ s/\..+//; 
my $tmp_dir = $out."/tmp_iso";
if(not -e $tmp_dir)
{
	mkdir($tmp_dir);
}


open SAM,"<$sam_file";
my @sam = <SAM>;
close SAM;


open POS,"<$posTable";
my @posTab = <POS>;
close POS;

my $block_size = int(scalar @posTab)/$core + 1;

my $max_threads = $core;
my $semaphore=new Thread::Semaphore($max_threads);
my $start = 0;
my $end = 0;
for( my $index = 0; $index < $core; $index ++)
{
	if($start > $#posTab)
	{
		last;
	}
	$end = $start + $block_size;
	if($end > $#posTab)
	{
		$end = $#posTab;
	}
	my @tmp = @posTab[$start..$end];
	$semaphore->down();
	my $thread = threads->new(\&TestPart,\@tmp,\@sam,"$tmp_dir/TMP_$index");
	$thread->detach();
	$start = $end + 1;
}

&Wait2Quit($max_threads);

sub Wait2Quit
{
	my $max_threads = shift;
	print "Waiting to quit...\n";
	my $num = 0;
	while( $num < $max_threads)
	{
		$semaphore->down();
		$num ++;		
		print "$num thread quit.\n";
	}
	print "All $max_threads thread quit.\n";
}




sub TestPart()### invoke TestPart(tab,sam,name)
{
	my $tab = shift;
	my $sam = shift;
	my $name = shift;
	for my $line(@{$tab})
	{
		chomp $line;
		my @arr = split/\t/,$line;
		my $taillen = &LoadCoveredSAM($sam,$arr[1]);
		for my $t(@{$taillen})
		{
			#print $arr[1],"\t",join("\t",@{$t}),"\n";
			push @{$hash_set{$arr[1]}{${$t}[-1]}},${$t}[1];
		}
	}
	open OUT,">$name";
	for my $k(sort{$a<=>$b} keys %hash_set)
	{	
		my %hash_tmp = ();
		for my $s( keys %{$hash_set{$k}})
		{
			if($#{$hash_set{$k}{$s}} > 1)
			{
				$hash_tmp{$k}{$s} = $hash_set{$k}{$s};
			}
			else
			{
				next;
			}
		}
		if(scalar keys %{$hash_tmp{$k}} >= 2)
		{
			my @set = keys %{$hash_tmp{$k}};
			for(my $i=0;$i<$#set;$i++)
			{
				for(my $j=$i+1;$j<=$#set;$j++)
				{			
					my @temp1 = @{$hash_tmp{$k}{$set[$i]}};
					my @temp2 = @{$hash_tmp{$k}{$set[$j]}};
					if(($#temp1+1>=$PMread) && ($#temp2+1 >=$PMread)){
					print OUT $k,"\t",$set[$i],"\t",$set[$j],"\t",&Ttest($hash_tmp{$k}{$set[$i]},$hash_tmp{$k}{$set[$j]}),"\n";
				#	print "@{$hash_tmp{$k}{$set[$i]}}\n@{$hash_tmp{$k}{$set[$j]}}\n";
			}
				}
			}
		}		
	}
	close OUT;
	$semaphore->up();
}


sub Ttest()
{
	my $a = shift;
	my $b = shift;
	my $test = new Statistics::TTest;
	#print "original $test\n";
	$test->load_data($a,$b);
	#print "$test\t$a\t$b\n";
	return $test->{'t_prob'};
	
}




sub LoadCoveredSAM()
{
	my $sam = shift;
	my $point = shift;
	my @out = ();
	print "$point\n";
	for my $line(@{$sam})
	{
		chomp $line;
	
		my @arr = split/\t/,$line;
		#if($arr[5] =~ /[I,D]/g)
		#{
		#	print "$arr[5]**********\n";
		#}


###########求reads覆盖边界是否包含posit
			my @match = $arr[5] =~ /(\d+)[MDN]/g;
			my $match_sum = &sum(@match);
			my $start = $arr[3];
			my $end = $start+$match_sum - 1;
			if($point<$start || $point >$end)
			{
				#print "$line\n";
				next;
			}	

##############
			my $bs = '';
			my $bq = '';
			if(($arr[1] & 0x100) != 0)
			{
				print "$line\n";
				next;
			}	



###########计算reads长度 $mnum
		my @ms1 = $arr[5] =~/(\d+[MHSI])/g;
		my $mnum=0;
		foreach my $idc(@ms1){
			$idc =~tr/A-Z//d;
			$mnum += $idc;
		}	



			my %hash_subposit;
		  my %hash_realposit;


		######以genome site 为步长，计算对应reads site
		my @array = $arr[5] =~/(\d+[A-Z])/g;
		
		my $readsstartsite=0;
		my $genomestartsite=$arr[3]-1;
		my $leftsflag =0;
		my $mflag=0;
	  foreach my $ida(@array){
	  	my $ia = $ida;
	  	my $ib = $ida;
	  	$ia =~tr/A-Z//d;
	  	#print $ia,"\n";
			$ib =~tr/0-9//d;
			#print $ib,"\n";
			
			if(($mflag == 0 )&&($ib eq "H")){
				$leftsflag = $ia;
			}			

			
			if(($ib eq "H")||($ib eq "S")){
				$readsstartsite += $ia;
				next;
			}
			if($ib eq "M"){
				for(1..$ia){
					$readsstartsite++;
					$genomestartsite++;
					$hash_subposit{$genomestartsite}=$readsstartsite;				
				}
				$mflag++;
			}
			if(($ib eq "D")||($ib eq "N")){
				for(1..$ia){
					$genomestartsite++;					
				}
			}
			if($ib eq "I"){
				for(1..$ia){
					$readsstartsite++;					
				}
			}
		}
################如果posit含有对应的reads上的碱基（即不是indel）则从sam第10行截碱基.$hash_subpisit{$_}就是reads实际碱基位置，含H
			if (exists $hash_subposit{$point}){
				my $alleleposit = $hash_subposit{$point} - $leftsflag;
				#print "Position in genome = $key2 \n","Real offset of sequence in samfile = $alleleposit = $hash_subposit{$key2} - $leftsflag H \n";
				$bs = substr($arr[9],$alleleposit-1,1);
				$bq = substr($arr[10],$alleleposit-1,1);
				#print $pp[0],"\t",$firstc,"\t", "Real position of reads =",$hash_realposit{$key2},"\n";

				
				#print "$bs\t$bq\n$alleleposit\n$line\n";
				

			}else{
				next;
			}
			
			
	my $tail_len = $hash_subposit{$point};
     
			
			
			
			if(ord($bq)-33 < 20)
			{
				next;
			}
			my $ratio = $tail_len/$mnum;
			#print "$ratio\n";
			if($ratio>1)
			{
				$ratio = 1/$ratio;
			}
			my @info = ($arr[0],$ratio,$tail_len,$start,$arr[5],$bs);
			push @out,\@info;
						
		
	}
	return \@out;
	
}



sub sum()
{
	my $sum = 0;
	for my $a(@_)
	{
		$sum += $a;
	}
	return $sum;
}

sub ave()
{
	my $ave = 0;
	return &sum(@_)/($#_+1);
}