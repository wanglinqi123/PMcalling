#!usr/bin/perl
use strict;

my %hash;
my $file=0;
open IN,"$ARGV[0]" or die;
while(<IN>){
	if($file==0){
		$file++;
		next;
		}
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	if($data[1] eq 'D'){
		my $i=$data[0];
		for(0..$data[3]-1){		
			$hash{$i}=1;
			$i+=1;
		}}else{
			$hash{$data[0]}=1;
			}
		}
close IN;
my %hash_PM;
open IN,"$ARGV[1]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash_PM{$data[1]}=$_;
	}
close IN;

my $len=$ARGV[2];
my $i=0;
my $n;
$n=0;
open OUT,">$ARGV[1]\.flapping_indel$ARGV[2]\.txt";
foreach my $key(sort{$a<=>$b}keys %hash_PM){
	$n=0;
	for($i=0;$i<=$len;$i++){
		my $a=$key-$i;
		my $b=$key+$i;
		if(exists $hash{$a} or exists $hash{$b}){
			$n++;
			}
		}
	if($n>0){
		print OUT"$hash_PM{$key}"."\t"."flapping_indel\n";
	}else{
		print OUT"$hash_PM{$key}"."\t"."PASS\n";
	}
	}
close OUT