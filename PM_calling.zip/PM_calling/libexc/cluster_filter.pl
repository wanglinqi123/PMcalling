 #!usr/bin/perl
use strict;

my @id;
my %sam;
my $len;
my $start;
my $end_num;
my %fixedPM;
my %rawPM;
open IN,"$ARGV[1]" or die;
$len=$ARGV[3];
my $cluster;
$cluster=$ARGV[4];
open OUTA,">$ARGV[0]\_$ARGV[3]\_tmpcluster$ARGV[4]\.txt";
open OUT,">$ARGV[0]\_$ARGV[3]\_de\_cluster$ARGV[4]\_filter\.txt";
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$rawPM{$data[1]}=$_;
	}
	close IN;
open IN,"$ARGV[2]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$fixedPM{$data[1]}=$_;
	}
	close IN;
my $nn;
my $nnn;
my $n;
my @total1;
my $total;
open IN,"$ARGV[0]" or die;
while(<IN>){
	my %hash;
	$total=0;
	my %PM;
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	push @id,$data[0];
	$sam{$data[0]}=$_;
	foreach my $one(@data){
		if($one=~/MD/){
			my @MD=split(/\:/,$one);
			my $two=$MD[2];
		my @two =	$two=~m/(\d+)/g;
		my @total= $data[5]=~m/(\d+)/g;
		my $ii;
		for($ii=0;$ii<=$#total;$ii++){
			$total+=$total[$ii];
			}
		my @indel;
			my $sum=0;
			 @total1= $data[5]=~/(\d+[A-Z])/g;;
		foreach my $ida(@total1){
			my $ia = $ida;
	  	my $ib = $ida;
	  	$ib =~tr/A-Z//d;
	  	$ia =~tr/0-9//d;
	  	#$ia=M
	  	if($ia eq 'H' or $ia eq 'S'){
	  		next;
	  		}
	  	if($ia eq 'M'){
	  		$sum+=$ib;
	  		}
	  		if($ia eq 'I'){
	  			my $indel=$sum+$data[3];
	  			#print "$indel\n";
	  			push @indel,$indel;
	  			}
	  			if($ia eq 'D'){
	  		$sum+=$ib;
	  		}
	  	}
		if($#two>0){
			$end_num=$two[-1];
			$start=$two[0];
			if($start<=3){
			  $n=0;		
				pop @two;	
			my $loci=$data[3]+$two[0];
			if(exists $fixedPM{$loci} or exists $rawPM{$loci}){
				$n=1;
			}else{
				$n=0;
				}
				my $i;
			for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			 #print "$data[0]\t$loci\n";
			  if(exists $fixedPM{$loci} or exists $rawPM{$loci}){
			  	$n=0;
			  	}
			  }
			 if($#two==0){
			 	$n=1;
			 	}
			if($n==1){
				$hash{$data[0]}=100000;
			}else{
					my $ii;
						my $i=1;
		     	my $yy;
		     	my $indel_1=0;
			my @data5=split(/\d+/,$data[5]);
			
			my $loci=$data[3]+$two[0];
			if(exists $fixedPM{$loci}){
				$hash{$data[0]}=0;
			}else{
				$hash{$data[0]}=1;
				}
				foreach my $one(@indel){
				for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			  my $a=0;
			  my $aa=$one-$loci;
			  $aa=-$aa if($aa<0);
			  		if($aa<=$len){
			 $a++;
			}
			}
			if($a>0){
				$indel_1++;
				}
				}	
				$hash{$data[0]}=$hash{$data[0]}+$indel_1;
			for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			  if(exists $fixedPM{$loci}){
			  	#print "$data[0]\t$loci\n";
			  	}else{
			  		if($two[$i]<=$len){
			 $hash{$data[0]}++;
			}
			 	}
				}	
				}				
				}elsif($end_num<=3){
			  $n=0;		
				pop @two;	
			my $loci=$data[3]+$two[0];
			my $del=$sum-$end_num-1;
			if(exists $fixedPM{$del} or exists $rawPM{$del}){
				$n=1;
			}else{
			$n=0;
				}
				my $i;
			for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			 #print "$data[0]\t$loci\n";
			  if(exists $fixedPM{$loci} or exists $rawPM{$loci}){
			  	$n=0;
			  	}
			  }
			 if($#two==0){
			 	$n=1;
			 	}
			if($n==1){
				$hash{$data[0]}=100000;
			}else{
					my $ii;
						my $i=1;
		     	my $yy;
		     	my $indel_1=0;
			my @data5=split(/\d+/,$data[5]);
			
			my $loci=$data[3]+$two[0];
			if(exists $fixedPM{$loci}){
				$hash{$data[0]}=0;
			}else{
				$hash{$data[0]}=1;
				}
				foreach my $one(@indel){
				for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			  my $a=0;
			  my $aa=$one-$loci;
			  $aa=-$aa if($aa<0);
			  		if($aa<=$len){
			 $a++;
			}
			}
			if($a>0){
				$indel_1++;
				}
				}	
				$hash{$data[0]}=$hash{$data[0]}+$indel_1;
			for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			  if(exists $fixedPM{$loci}){
			  	#print "$data[0]\t$loci\n";
			  	}else{
			  		if($two[$i]<=$len){
			 $hash{$data[0]}++;
			}
			 	}
				}	
				}
				}else{
					 $nn=0;
					my $ii;
						my $i=1;
		     	 $nnn=0;
		     	my $yy;
	
			pop @two;	
			my $loci=$data[3]+$two[0];
			my $indel_1=0;
			my @data5=split(/\d+/,$data[5]);
				foreach my $one(@indel){
				for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			  my $a=0;
			  my $aa=$one-$loci;
			  $aa=-$aa if($aa<0);
			  		if($aa<=$len){
			 $a++;
			}
			}
			if($a>0){
				$indel_1++;
				}
				}	
			if(exists $fixedPM{$loci}){
				$hash{$data[0]}=0;
			}else{
				$hash{$data[0]}=1;
				}
				$hash{$data[0]}=$hash{$data[0]}+$indel_1;
			#print "$data[0]\t$loci\n";
			for($i=1;$i<=$#two;$i++){
			  $loci+=$two[$i]+1;
			 #print "$data[0]\t$loci\n";
			  if(exists $fixedPM{$loci}){
			  	#print "$data[0]\t$loci\n";
			  	}else{
			  		if($two[$i]<=$len){
			 $hash{$data[0]}++;
			}
			 	}
				}
	}
		}
	}
}
my $start_loci=$data[3];
my $end_loci=$data[3];
 foreach my $ida(@total1){
	  	my $ia = $ida;
	  	my $ib = $ida;
	  	$ia =~tr/A-Z//d;
			$ib =~tr/0-9//d;
			if($ib eq "H"){
				next;
			}						
			if(($ib eq "H")||($ib eq "S")){
				next;
			}
			if($ib eq "M"){
				$end_loci+=$ia;
			}
			if(($ib eq "D")||($ib eq "N")){
				$end_loci+=$ia;
			}
			if($ib eq "I"){
				next;
			}
		}
  my $i;
  for($i=$start_loci;$i<=$end_loci;$i++){
				if(exists $rawPM{$i}){
					#print "$mismatch\n";
					$PM{$data[0]}.="$i".",";
					}
	}

if($hash{$data[0]}>=$cluster){
	if(exists $PM{$data[0]}){
		$PM{$data[0]}=~s/\,$//g;
	if($hash{$data[0]}==100000){
			print OUTA"$data[2]\t$data[0]\t$start_loci\t$end_loci\tend\t$PM{$data[0]}\n";
		}else{
	print OUTA"$data[2]\t$data[0]\t$start_loci\t$end_loci\t$hash{$data[0]}\t$PM{$data[0]}\n";
}	
	}
	}else{
		#print "$key\t$hash{$key}\n";
		print OUT"$_\n";
		}
	}

close IN;
close OUT;

close OUTA;

open IN,"$ARGV[0]\_$ARGV[3]\_tmpcluster$ARGV[4]\.txt";
open OUTA,">$ARGV[0]\_$ARGV[3]\_cluster$ARGV[4]\.txt";
print OUTA"##end:"."\t"."the PM at the end of read and only exists one\n";
#print OUTA"##-:"."No PM site in this read but multiple mismatchs in it\n";
print OUTA"chr\tread_name\tstart_location\tend_location\tmismatchs\tloci\n";
my %filter;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$filter{$data[1]}.="$_"."..";
	}
	close IN;
foreach my $key(sort{$a<=>$b} keys %filter){
	my @data=split(/\.\./,$filter{$key});
	foreach my $one(@data){
	print OUTA"$one\n";
	}
}

close OUTA;

system("unlink $ARGV[0]\_$ARGV[3]\_tmpcluster$ARGV[4]\.txt");