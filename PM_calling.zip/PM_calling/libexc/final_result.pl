#!usr/bin/perl
use strict;
my %hash1;
my %hash2;
my %hash3;
open IN,"$ARGV[0]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash1{$data[1]}=$_;
	}
close IN;

open IN,"$ARGV[1]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash2{$data[1]}=$_;
	}
close IN;

open IN,"$ARGV[2]" or die;
while(<IN>){
	$_=~tr/\r\n//d;
	my @data=split(/\t/,$_);
	$hash3{$data[1]}=$_;
	}
close IN;
open OUT,">$ARGV[3]\.txt";
foreach my $key(sort{$a<=>$b}keys %hash1){
	if($key){
	if(exists $hash2{$key} and exists $hash3{$key}){
		print OUT"$hash1{$key}\n";
		}
}
}
close OUT;