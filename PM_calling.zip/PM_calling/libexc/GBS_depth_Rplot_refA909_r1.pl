#!usr/bin/perl -w 
use strict;
use warnings;

&USAGE if (@ARGV<2);
#ֻ�������ļ��й��е��ַ����ɣ���ҪС�� �� GBS2 �� GBS206S7 �ᷢ�����ţ���ֿ�Ŀ¼���м���
sub USAGE{
	print "\n\n\n\n";
	print "USAGE:perl $0 length_reference sample1 sample2 sample3....";
	print "\n\n\n\n";
	die "$!\n";
	}
my @all = @ARGV;
my $genomelength = shift @all; #ref genome �ĳ��ȣ�A909Ϊ2127839�����Ըĳ�������ֵ
my $out=shift @all;
my $mapquality=shift @all;
my $maplength=shift @all;
chdir "$out";
my @file=glob("*.depth");
sub main (){
	foreach my $id(@all){
		my $vfile1;
		my $vfile2;
		my $vfile3;
		my $flag=0;
		foreach my $fid(@file){
			print $fid,"\n";
			if($fid =~ /$id/){
				#print $fid,"\n";
				if($fid =~ /F4.sort.bam.depth$/){
					$vfile1=$fid;
					#print "$vfile1\n";
					$flag++;
				}
				if($fid =~ /q$mapquality.txt.sort.bam.depth$/){
					$vfile2=$fid;
					#print "$vfile2\n";
					$flag++;
				}				
				if($fid =~ /$maplength\_Mresult.txt.sort.bam.depth$/){
					$vfile3=$fid;
					#print "$vfile3\n";
					$flag++;
				}
			}
		}
		if($flag<3){
			print "There are not enough depth files for $id!\n";
			next;
		} 		
		
		print $id,"\n";	
		my $cov;
	  open(IN,"$vfile1.sum") or die "$!";
	  while(my $line=<IN>){
			chomp($line);
			$line=~tr/\r\n//d;
			my @pp = split (/\t/,$line);
			$cov = $pp[0];
		}
		close IN or die "$!";
		my $avecov = $cov/$genomelength;
		my $cov2 = 2*$avecov;
		my $covhalf = 0.5 * $avecov;
		
		open (OUT,">$id.plot.R") or die "$!";
		print OUT "
data1<-read.table(\"$vfile1\")
data2<-read.table(\"$vfile2\")
data3<-read.table(\"$vfile3\")

xx<-seq(0,$genomelength,by=1000)/1000
yy<-paste(xx,\"k\",sep=\"\")
aa = c(0,$genomelength)
bb=c($cov2,$cov2)
cc=c($covhalf,$covhalf)

pdf(\"$id\_w800h5.pdf\", width = 800, height = 5) #�˴������޸����ͼ��ĳ�����������

plot(data1\$V2,data1\$V3,type=\'l\',col=\'red\',xlim=c(0,$genomelength),ylim=c(0,1000),ylab=\'depth\',xlab=\'\',main=\'$id\',xaxt=\'n\')
par(new=TRUE)
plot(data2\$V2,data2\$V3,type=\'l\',col=\'blue\',xlim=c(0,$genomelength),ylim=c(0,1000),ylab=\'\',xlab=\'\',main=\'$id\',xaxt=\'n\')
par(new=TRUE)
plot(data3\$V2,data3\$V3,type=\'l\',col=\'green\',xlim=c(0,$genomelength),ylim=c(0,1000),ylab=\'\',xlab=\'\',main=\'$id\',xaxt=\'n\')
axis(1,at=seq(0,$genomelength,by=500),labels=FALSE,las=2)
axis(1,at=seq(0,$genomelength,by=1000),labels=yy,las=2)
lines(aa,bb,col=\"black\",lwd=1,lty=2)
lines(aa,cc,col=\"black\",lwd=1,lty=2)  

dev.off()
";
close OUT or die "$!";

system("R<$id.plot.R --vanilla");			
	
  }				
}
&main;
